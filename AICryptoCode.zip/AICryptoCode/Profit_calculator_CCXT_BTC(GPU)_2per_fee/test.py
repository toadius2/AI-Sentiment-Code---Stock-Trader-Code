import os
import plotly
from plotly.graph_objs import Scatter
from plotly.graph_objs.scatter import Line
import torch
import pandas as pd
import pickle

import matplotlib.pyplot as plt
import numpy as np
import os.path

from env import Env
import itertools

# Globals
Ts, rewards, Qs, best_avg_reward = [], [], [], -1e10
percent_correct = []  # set empty array for pandas use


def plot_confusion_matrix(classes, y_true, y_pred, normalize=False, title='Confusion matrix', cmap=plt.cm.Blues):
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1, 2])

    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    plt.clf()

    #change added return function for confusion matrix for comparison
    return cm


# Test DQN
def test(args, T, dqn, val_mem, train_df, train_label, timestamp, init_act, s, evaluate=False):
    global Ts, rewards, Qs, best_avg_reward
    count_iter = 0

    env = Env(args, train_df, train_label, init_act, s, count_iter)
    env.eval()
    Env.timestamp = timestamp
    Ts.append(T)
    T_rewards, T_Qs = [], []
    acc_act = []
    # Test performance over several episodes
    done = True
    count = 0
    train_label = train_label.values
    action_list = []  #Change 1
    #print ("action_list reset")

    for _ in range(args.evaluation_episodes):
        count = 0

        while True:
            if done:
                state, actualLabel, timestampatSpecificePoint,feature_data = env.reset()
                reward_sum, done = 0, False
            action = dqn.act_e_greedy(state)  # Choose an action ε-greedily
            state, reward, done = env.step(action)  # Step

            reward_sum += reward

            acc_act.append(action)
            #action_list[action] += 1
            action_list.append(action)  #Change 2
            # print("Action: {} at T = {}".format(action,Env.timestamp))
            # print("timestamp : \n{}".format(timestamp))
            count += 1
            if count % 5000 == 0:
                print(count)

            if done:
                T_rewards.append(reward_sum)
                correct = 0
                for i, x in enumerate(train_label):
                    if acc_act[i] == x:
                        correct += 1

                percent_correct.append(correct / len(train_label))
                pf = pd.DataFrame(percent_correct)  # This is super convuluted, because pandas REQUIRES an array/list
                pf.to_csv('percent_correct_training.csv')
                print("% Correct:", correct / len(train_label))

                #Change #something added vars to store (only care about rcm_compare (non-normalized cm)
                _ = plot_confusion_matrix([0, 1, 2], train_label, acc_act, normalize=True,
                                      title='Confusion matrix', cmap=plt.cm.Blues)
                #change 3 for comparing confusion matrix
                rcm_compare = plot_confusion_matrix([0, 1, 2], train_label, acc_act, normalize=False,
                                      title='Raw Confusion matrix', cmap=plt.cm.Blues)
                break
    #print("[Test] List of Actions ({}) : {}".format(len(action_list), action_list))
    # reee = pd.DataFrame(columns = 'action')
    # pickle.dump(actions[1:], open('bnb_labeled_cpy.p', 'wb'))

    # Test Q-values over validation memory
    for state in val_mem:  # Iterate over valid states
        T_Qs.append(dqn.evaluate_q(state))

    avg_reward, avg_Q = sum(T_rewards) / (len(T_rewards) + 0.000000001), sum(T_Qs) / (len(T_Qs) + 0.00000001)
    if not evaluate:
        # Append to results
        rewards.append(T_rewards)
        Qs.append(T_Qs)

        # Plot
        _plot_line(Ts, rewards, 'Reward', path='results')
        _plot_line(Ts, Qs, 'Q', path='results')

        # Save model parameters if improved
        if avg_reward > best_avg_reward:
            best_avg_reward = avg_reward
            dqn.save('results')
    # Return average reward and Q-value
    return avg_reward, avg_Q, action, actualLabel, timestampatSpecificePoint, action_list, rcm_compare,feature_data  #Change 3 (add action_list and raw confusion matrix)


# Plots min, max and mean + standard deviation bars of a population over time
def _plot_line(xs, ys_population, title, path=''):
    max_colour, mean_colour, std_colour, transparent = 'rgb(0, 132, 180)', 'rgb(0, 172, 237)', 'rgba(29, 202, 255, 0.2)', 'rgba(0, 0, 0, 0)'

    ys = torch.tensor(ys_population, dtype=torch.float32)
    ys_min, ys_max, ys_mean, ys_std = ys.min(1)[0].squeeze(), ys.max(1)[0].squeeze(), ys.mean(1).squeeze(), ys.std(
        1).squeeze()
    ys_upper, ys_lower = ys_mean + ys_std, ys_mean - ys_std

    trace_max = Scatter(x=xs, y=ys_max.numpy(), line=Line(color=max_colour, dash='dash'), name='Max')
    trace_upper = Scatter(x=xs, y=ys_upper.numpy(), line=Line(color=transparent), name='+1 Std. Dev.', showlegend=False)
    trace_mean = Scatter(x=xs, y=ys_mean.numpy(), fill='tonexty', fillcolor=std_colour, line=Line(color=mean_colour),
                         name='Mean')
    trace_lower = Scatter(x=xs, y=ys_lower.numpy(), fill='tonexty', fillcolor=std_colour, line=Line(color=transparent),
                          name='-1 Std. Dev.', showlegend=False)
    trace_min = Scatter(x=xs, y=ys_min.numpy(), line=Line(color=max_colour, dash='dash'), name='Min')

    plotly.offline.plot({
        'data': [trace_upper, trace_mean, trace_lower, trace_min, trace_max],
        'layout': dict(title=title, xaxis={'title': 'Step'}, yaxis={'title': title})
    }, filename=os.path.join(path, title + '.html'), auto_open=False)
