import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import requests
import datetime
import pickle
import nltk
nltk.download('vader_lexicon')
from nltk.tokenize import sent_tokenize
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from collections import defaultdict
from newspaper import Article
from bs4 import BeautifulSoup
import time


class Sentiment():
    class sentimentAnalysis(object):

        def __init__(self, **kwargs):
            self.index = ['BTC', 'ETH', 'EOS', 'LTC', 'XRP', 'BCH',
                          'ETC', 'XMR', 'ZEC', 'QTUM', 'NEO',
                          'TRX', 'BTM', 'KEY', 'TRUE', 'XUC', 'XLM', 'DASH',
                          'USDT', 'BTS', 'BIX', 'OMG', 'AST', 'UBTC', 'WPR', 'BNB',
                          'PAX', 'ZRX', 'HSR', 'RVN', 'ADA', 'OKB', 'GTO', 'TUSD',
                          'BAT', 'GVT', 'DOGE', 'DENT', 'XIN', 'MITH', 'PHX',
                          'BCPT', 'GNT', 'SC', 'IOT', 'DLT', 'WTC', 'PAI', 'VET', 'ICX',
                          'NPXS', 'ONT', 'STORM', 'WAVES', 'AE', 'WAN', 'NCASH', 'LSK',
                          'XEM', 'ARN', 'HYDRO', 'ELF', 'APIS', 'IOST', 'MDA', 'DOCK', 'ETF',
                          'XVG', 'ZIL', 'QASH', 'QKC', 'KNC', 'TNT', 'POLY', 'MBT', 'HT', 'MGO',
                          'IOTX', 'SWFTC', 'BLZ', 'BTG', 'PAL', 'DNT', 'INT', 'MFT', 'MTH',
                          'BMX', 'SRN', 'GO', 'BCD', 'NOAH', 'UBEX', 'NAS', 'LINK', 'ZEN', 'MCO',
                          'DGD', 'BBK', 'ABT', 'YOYOW']
            self.coin_names = {'bitcoin': 'BTC',
                               'ethereum': 'ETH',
                               'litecoin': 'LTC',
                               'bitcoin cash': 'BCH',
                               'ethereum classic': 'ETC',
                               'monero': 'XMR',
                               'zcash': 'ZEC',
                               'tron': 'TRX',
                               'bytom': 'BTM',
                               'selfkey': 'KEY',
                               'true chain': 'TRUE',
                               'exchange union': 'XUC',
                               'stellar': 'XLM',
                               'cardano': 'ADA',
                               'Tether': 'USDT',
                               'Bitshares': 'BTS',
                               'BiboxCoin': 'BIX',
                               'OmiseGo': 'OMG',
                               'AirSwap': 'AST',
                               'UnitedBitcoin': 'UBTC',
                               'WePower': 'WPR',
                               'Binance Coin': 'BNB', 'Paxos Standard': 'PAX', '0x': 'ZRX', 'Hshare': 'HSR',
                               'Ravencoin': 'RVN',
                               'Cardano': 'ADA', 'Okex': 'OKB', 'GIFTO': 'GTO', 'True USD': 'TUSD',
                               'Basic Attention Token': 'BAT', 'Genesis Vision': 'GVT', 'Dogecoin': 'DOGE',
                               'Innity Economics': 'XIN',
                               'Mithril': 'MITH', 'Red Pulse Phoenix': 'PHX', 'BlockMason Credit Protocol': 'BCPT',
                               'Golem Network Token': 'GNT', 'Siacoin': 'SC', 'IOTA': 'IOT', 'Agrello Delta': 'DLT',
                               'Waltonchain': 'WTC', 'Project Pai': 'PAI', 'Vechain': 'VET', 'ICON Project': 'ICX',
                               'Pundi X': 'NPXS', 'Ontology': 'ONT', 'Aeternity': 'AE', 'Wanchain': 'WAN',
                               'Nucleus Vision': 'NCASH',
                               'Lisk': 'LSK', 'NEM': 'XEM', 'Aeron': 'ARN', 'Hydrogen': 'HYDRO', 'aelf': 'ELF',
                               'IOS token': 'IOST',
                               'Moeda': 'MDA', 'Dock.io': 'DOCK', 'EthereumFog': 'ETF', 'Verge': 'XVG',
                               'Zilliqa': 'ZIL', 'Quoine Liquid': 'QASH',
                               'QuarkChain': 'QKC', 'Kyber Network': 'KNC', 'Tierion': 'TNT',
                               'Polymath Network': 'POLY', 'Multibot': 'MBT',
                               'Huobi Token': 'HT', 'MobileGo': 'MGO', 'IoTeX Network': 'IOTX', 'SwftCoin': 'SWFTC',
                               'Bluzelle': 'BLZ',
                               'Bitcoin Gold': 'BTG', 'PolicyPal Network': 'PAL', 'district0x': 'DNT',
                               'Internet Node Token': 'INT',
                               'Mainframe': 'MFT', 'Monetha': 'MTH', 'BitMart Coin': 'BMX', 'SirinLabs': 'SRN',
                               'GoChain': 'GO',
                               'Bitcoin Diamond': 'BCD', 'NOAHCOIN': 'NOAH', 'Nebulas': 'NAS', 'ChainLink': 'LINK',
                               'Horizen': 'ZEN',
                               'Crypto.com': 'MCO', 'Digix DAO': 'DGD', 'BitBlocks': 'BBK', 'ArcBlock': 'ABT'}
            for i in self.index:
                self.coin_names[i.lower()] = i

            self.sentiment = pd.DataFrame(np.empty((len(self.index), 6), dtype=object), index=self.index,
                                          columns=['Last_News_Updated_Time', 'Current_sentiment', 'Last_sentiment',
                                                   'Current_Overall_Market_sentiment', 'Last_Overall_Market_sentiment',
                                                   'Market_Price'])
            self.sentiment.Market_price = 0
            self.sentiment.Last_News_Updated_Time = None
            self.overall_market_w = 0.3
            self.last_senti_w = 0.3
            self.last_overall_market_w = 0.3
            self.overall_market = None
            self.last_overall_market = None

        def sentence_tokenizer(self, article_list):
            sent_tokenize_list = []
            for text in article_list:
                text = text.lower()
                sent_tokenize_list.append(sent_tokenize(text))
            return sent_tokenize_list

        def calculate(self, data_s):
            news_articles = list(data_s.Text)
            news_sentences_list = self.sentence_tokenizer(news_articles)
            sid = SentimentIntensityAnalyzer()
            vader_sent = defaultdict(list)
            data_s_senti_list = []
            for j in range(len(news_sentences_list)):
                article = news_sentences_list[j]
                text = ' '.join(article)
                show_keys = [key for key in self.coin_names.keys() if key in text]
                tmp_coin_senti = defaultdict(list)

                for idx in range(len(article)):
                    current_sentence = article[idx]
                    sentiment = sid.polarity_scores(current_sentence)['compound']
                    # if sentiment is zero, we don't use it
                    if sentiment == 0:
                        continue
                    if len(show_keys) > 0:
                        for key in show_keys:
                            if key in current_sentence:
                                vader_sent[self.coin_names[key]].append(sentiment)
                                tmp_coin_senti[self.coin_names[key]].append(sentiment)
                                step = idx + 1
                                # check next 3 sentences' sentiments and add them to the current key.
                                while step < len(article) and step - idx < 4:
                                    current_sentence = article[step]
                                    sentiment = sid.polarity_scores(current_sentence)['compound']
                                    # if sentiment is zero, we don't use it
                                    if sentiment == 0:
                                        step += 1
                                        continue
                                    vader_sent[self.coin_names[key]].append(sentiment)
                                    tmp_coin_senti[self.coin_names[key]].append(sentiment)
                                    step += 1
                            else:
                                vader_sent['overall_market'].append(sentiment)
                                tmp_coin_senti['overall_market'].append(sentiment)
                    else:
                        vader_sent['overall_market'].append(sentiment)
                        tmp_coin_senti['overall_market'].append(sentiment)

                mean_dict = defaultdict(float)
                for k, v in tmp_coin_senti.items():
                    mean_dict[k] = float('%.3f' % np.array(v).mean())
                data_s_senti_list.append(mean_dict)
            data_s['Sentiment'] = np.array(data_s_senti_list)
            output = defaultdict(float)
            # mean of each sentences
            for key, value in vader_sent.items():
                output[key] = float('%.3f' % np.array(value).mean())
            # mean of each articles
            # =============================================================================
            #         for key, value in vader_sent.items():
            #              output[key] = float('%.3f'%(np.array(value).sum()/len(news_sentences_list))) #too big!
            # =============================================================================

            # update overall market sentiment
            self.last_overall_market = self.overall_market
            if self.last_overall_market:
                self.overall_market = float('%.3f' % (output['overall_market'] * (
                            1 - self.last_overall_market_w) + self.last_overall_market * self.last_overall_market_w))
            else:
                self.overall_market = output['overall_market']
            output.pop('overall_market', None)
            return output, data_s

        def senti_analyzer(self, data_list):
            flat_list = [item for sublist in data_list for item in sublist]
            data = pd.DataFrame(flat_list, columns=['Title', 'Text', 'Date', 'Source'])
            the_time = data.Date[0]
            data = data.reset_index(drop=True)
            current_sentiment_dict, news_data = self.calculate(data)
            # update columns of overall market
            self.sentiment.Current_Overall_Market_sentiment = self.overall_market
            self.sentiment.Last_Overall_Market_sentiment = self.last_overall_market
            for idx in self.sentiment.index:
                # if there are new articles about this coin, update it with new sentiment

                last_senti = self.sentiment.loc[idx]

                if idx in current_sentiment_dict.keys():
                    value = current_sentiment_dict[idx]
                    if last_senti[1] == None:
                        curr_sentiment = float('%.3f' % (
                                    value * (1 - self.overall_market_w) + self.overall_market_w * self.overall_market))
                        self.sentiment.loc[idx, :3] = np.array([the_time, curr_sentiment, None])
                    else:
                        # update current sentiment
                        t = float(value) * float(1 - self.last_senti_w)
                        tt = float(last_senti[1]) * float(self.last_senti_w)
                        curr_sentiment_weighted = t + tt
                        curr_sentiment = float('%.3f' % (curr_sentiment_weighted * (
                                    1 - self.overall_market_w) + self.overall_market_w * self.overall_market))
                        self.sentiment.loc[idx, :3] = np.array([the_time, curr_sentiment, float(last_senti[1])])
                else:
                    # If the coin doesn't show up in these recent articles then update it with overall market sentiment
                    # If it has been assigned
                    if last_senti[1]:
                        # if it was assigned with overall market sentiment, then again fill it with market sentiment
                        if float(last_senti[1]) == last_senti[4]:
                            self.sentiment.loc[idx, 1:3] = np.array([self.overall_market, float(last_senti[1])])
                        # if it was different from overall market value, then we can update it with the affect of overall market sentiment
                        else:
                            t = float(last_senti[1]) * float(1 - self.overall_market_w)
                            tt = float(self.overall_market_w) * float(self.overall_market)
                            curr_sentiment = float('%.3f' % (t + tt))
                            self.sentiment.loc[idx, 1:3] = np.array([curr_sentiment, float(last_senti[1])])
                    # If it has never been assigned, use market sentiment to fill
                    else:
                        self.sentiment.loc[idx, 1:3] = np.array([self.overall_market, last_senti[1]])

            return news_data

    class news_class():

        def __init__(self, current_time, website, stop, k=None):
            self.news_latest = ""
            self.current_time = current_time
            self.is_exist = False
            self.website = website
            # stop 10s after first scrape
            self.freq1 = 10
            # stop 30s
            self.freq2 = 30
            self.stop = stop
            self.news_latest = None
            if website in ["thebitcoinnews", "newsbtc", "cryptoslate", "coinstaker", "btcwires", "bitcoinist", "ccn"]:
                self.change_text = True
            else:
                self.change_text = False
            self.k = k

        def clean_text(self, text):
            pass

        def get_news(self, links):
            news_text = []
            self.news_latest = links[0]
            for link in links:
                date = self.current_time
                try:
                    article = Article(link.strip())
                    article.download()
                    article.parse()
                    text = article.text
                    if self.change_text:
                        text = self.clean_text(text)
                    if text:
                        news_text.append([article.title, text, date, self.website])
                except Exception as e:
                    print(e)
                    pass
            return news_text

        # def write_into_mysql():
        # pass

        def scraper(self, stop):
            pass

        def process_news(self, links):

            news = links
            if self.stop:
                print("{} Webscraper started time:{}\nWrote {} news".format(self.website, self.current_time, len(news)))
                news = self.get_news(news)
                return news
            else:
                # I don't think we have to write anything to a csv, just the console
                self.write_into_csv(news)
                print("{} Webscraper started time:{}\nWrote {} news".format(self.website, self.current_time, len(news)))

    class thebitcoinnews(news_class):
        def scraper(self):
            links = []
            url = 'https://thebitcoinnews.com/category/bitcoin-news/'
            try:
                r = requests.get(url)
                soup = BeautifulSoup(r.text, 'html.parser')

                for post in soup.find_all('div', class_='td-block-span6'):
                    link = post.find('a').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)
                if self.stop:
                    self.update_label_webscraper(self.process_news(links))
                    return self.process_news(links)
            except Exception as e:
                print(e)

        def clean_text(self, texxt):
            content = texxt.split("\n\n")
            keep = len(content)
            if keep < 5:
                return None
            if 'source' == content[-1][:6]:
                keep -= 2
            try:
                for i in range(len(content) - 1, len(content) - 8, -1):
                    if content[i] == "For the latest cryptocurrency news, join our Telegram!":
                        keep = i
                        break
            except Exception:
                pass
            return ("\n\n".join(content[:keep]))

    class newsbtc(news_class):
        def clean_text(self, texxt):
            content = texxt.split("\n\n")
            keep = len(content)
            if 'Featured' == content[-1][:8]:
                keep -= 1
            elif 'Previous' == content[-1][:8]:
                keep -= 2
            return ("\n\n".join(content[:keep]))

        def scraper(self):
            links = []
            urls = ['https://www.newsbtc.com/category/bitcoin', 'https://www.newsbtc.com/category/crypto/',
                    'https://www.newsbtc.com/category/crypto-tech/', 'https://www.newsbtc.com/category/industry-news/']
            try:
                r = requests.get(urls[self.k])
                soup = BeautifulSoup(r.text, 'html.parser')

                posts = soup.find('div', class_='row posts')
                for post in posts.find_all('div', class_='post-content'):
                    link = post.find('a', class_='link').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)
                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

    class cryptovest(news_class):
        def scraper(self):
            url = 'https://cryptovest.com/tag/bitcoin-news/'
            try:
                r = requests.get(url)
                soup = BeautifulSoup(r.text, 'html.parser')
                links = []

                for post in soup.find_all('div', 'col-12 col-md-6 col-lg-6 p--8 post'):
                    link = 'https://cryptovest.com' + post.find('a').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)
                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

    class cryptoslate(news_class):
        def scraper(self):
            links = []
            try:
                url = 'https://cryptoslate.com/news'
                r = requests.get(url)
                soup = BeautifulSoup(r.text, 'html.parser')

                for post in soup.find_all('div', class_='post small-post'):
                    link = post.find('h2').find("a").get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)
                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

        def clean_text(self, texxt):
            content = texxt.split("\n\n")
            content = content[:-2]
            if content[-1][-13:] == "CryptoCompare":
                content = content[:-1]
            return ("\n\n".join(content))

    class cointelegraph(news_class):
        def scraper(self):
            base_url = "https://cointelegraph.com"
            links = []
            try:
                r = requests.get(base_url)
                soup = BeautifulSoup(r.text, 'html.parser')
                recent = soup.find('section', id='post-content').find('div', class_='row')
                for post in recent.find_all('div', class_='post boxed'):
                    link = post.find('a').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)
                if self.stop:
                    return self.process_news(links)

            except Exception as e:
                print(e)

    class coinstaker(news_class):
        def scraper(self):
            url = 'https://www.coinstaker.com'
            try:
                r = requests.get(url)
                soup = BeautifulSoup(r.text, 'html.parser')
                links = []

                for post in soup.find_all('div', class_='blogpost'):
                    link = post.find('a').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)
                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

        def clean_text(self, texxt):
            content = texxt.strip().split("\n\n")
            keep = len(content)
            idx = keep
            while idx > 0 and idx > (len(content) - 6):
                if 'Read More' == content[idx - 1][:9]:
                    keep = idx - 1
                if 'You can also' == content[idx - 1][:12]:
                    keep = idx - 1
                if 'Join us' == content[idx - 1][:7]:
                    keep = idx - 1
                idx -= 1
            return ("\n\n".join(content[:keep]))

    class coinspeaker(news_class):
        def scraper(self):
            url = 'https://www.coinspeaker.com'
            try:
                r = requests.get(url)
                soup = BeautifulSoup(r.text, 'html.parser')
                links = []

                section = soup.find('div', class_='sectionContent')
                for post in section.find_all('div', class_='itemBlock'):
                    link = post.find('a').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)
                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

    class coindesk(news_class):
        def scraper(self):

            url = "https://www.coindesk.com/"
            try:
                r = requests.get(url)
                soup = BeautifulSoup(r.text, 'html.parser')
                links = []

                for post in soup.find_all('div', class_="post-info"):
                    link = post.find('a').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)
                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

    class ccn(news_class):
        def scraper(self):
            url = "https://www.ccn.com/"
            links = []
            try:
                headers = {'User-Agent': 'Mozilla/5.0'}
                r = requests.get(url, headers=headers)
                soup = BeautifulSoup(r.text, 'html.parser')
                posts = soup.find('div', 'posts-row')
                for post in posts.find_all('article'):
                    link = post.find('a').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)

                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

        def clean_text(self, texxt):
            content = texxt.split("\n\n")
            content = content[1:-3]
            return ("\n\n".join(content))

    class btcwires(news_class):
        def scraper(self):

            url = "https://www.btcwires.com/"
            try:
                r = requests.get(url)
                soup = BeautifulSoup(r.text, 'html.parser')
                links = []

                main_posts = soup.find("div", class_="home-post")
                for post in main_posts.find_all("div", class_="post-box"):
                    try:
                        detail = post.find('div', class_='post-details')
                        link = detail.find('a').get('href')
                        if link == self.news_latest:
                            break
                        else:
                            links.append(link)
                    except:
                        continue

                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

        def clean_text(self, texxt):
            content = texxt.strip().split("\n\n")
            keep = len(content)
            return ("\n\n".join(content[1:keep]))

    class bitcoinist(news_class):

        def scraper(self):
            links = []
            url = 'https://bitcoinist.com/latest-news'
            try:
                r = requests.get(url)
                soup = BeautifulSoup(r.text, 'html.parser')

                for post in soup.find_all('div', class_='news-content cf'):
                    news = post.find('h3', class_='title')
                    link = news.find('a').get('href')
                    if link == self.news_latest:
                        break
                    else:
                        links.append(link)

                if self.stop:
                    return self.process_news(links)
            except Exception as e:
                print(e)

        def clean_text(self, texxt):
            content = texxt.strip().split("\n\n")
            keep = len(content)
            return ("\n\n".join(content[:keep - 3]))

    def starter(self, object):

        self.current_time = datetime.datetime.now()
        # self.time_str = self.current_time.strftime("%Y_%m_%d_%H")
        scaper_btcwires = self.btcwires(self.current_time, "btcwires", True)
        scaper_bitcoinist = self.bitcoinist(self.current_time, "bitcoinist", True)
        scaper_coindesk = self.coindesk(self.current_time, "coindesk", True)
        scaper_ccn = self.ccn(self.current_time, "ccn", True)
        scaper_coindesk = self.coindesk(self.current_time, "coindesk", True)
        scaper_coinspeaker = self.coinspeaker(self.current_time, "coinspeaker", True)
        scaper_coinstaker = self.coinstaker(self.current_time, "coinstaker", True)
        scaper_cointelegraph = self.cointelegraph(self.current_time, "cointelegraph", True)
        scaper_cryptovest = self.cryptovest(self.current_time, "cryptovest", True)
        scaper_cryptoslate = self.cryptoslate(self.current_time, "cryptoslate", True)
        scaper_thebitcoinnews = self.thebitcoinnews(self.current_time, "thebitcoinnews", True)
        scaper_newsbtc_1 = self.newsbtc(self.current_time, "newsbtc", True, 0)
        scaper_newsbtc_2 = self.newsbtc(self.current_time, "newsbtc", True, 1)
        scaper_newsbtc_3 = self.newsbtc(self.current_time, "newsbtc", True, 2)
        scaper_newsbtc_4 = self.newsbtc(self.current_time, "newsbtc", True, 3)
        self.scrapers = [scaper_bitcoinist, scaper_btcwires, scaper_ccn, scaper_coindesk,
                         scaper_coinspeaker, scaper_coinstaker, scaper_cointelegraph, scaper_cryptovest,
                         scaper_cryptoslate, scaper_thebitcoinnews, scaper_newsbtc_1, scaper_newsbtc_2,
                         scaper_newsbtc_3, scaper_newsbtc_4]
        # self.scrapers = [scaper_bitcoinist,scaper_btcwires]
        self.curr_sentiment = self.sentimentAnalysis()
        return self.scrapers, self.curr_sentiment, self.current_time

    def report_start(self):
        self.current_time = datetime.datetime.now()
        print("______________________________")
        print("Sentiment analyzer starts on {}".format(self.current_time))

    # self.time_str = self.current_time.strftime("%Y_%m_%d_%H")

    def scrape(self):
        total_news = []
        # Go through each var in starter
        for cur_scraper in self.scrapers:
            cur_scraper.current_time = self.current_time
            # get's the data into the var
            news = cur_scraper.scraper()
            if news != None and len(news) > 0:
                total_news.append(news)

        if len(total_news) > 0:
            news_df = self.curr_sentiment.senti_analyzer(total_news)
            # news_df.to_csv("Sentiment.csv", mode='a')
            with pd.option_context('display.max_rows', None, 'display.max_columns', None, 'display.width', 5000):
                # iloc is related to pandas, don't know how to fix this error
                print(news_df.iloc[:, [0, 2, 4]])

            with pd.option_context('display.max_rows', None, 'display.max_columns', None, 'display.width', 5000):
                print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
                print(self.curr_sentiment.sentiment)
                data = self.curr_sentiment.sentiment
                # data.to_csv("CoinSentiment.csv")
                data.to_pickle("CoinSentiment.p")
                print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
            return 1
        else:
            print("No valid news to update.")
            return 0

    def report_end(self):
        self.current_time = datetime.datetime.now()
        print("Sentiment analyzer ends on {}".format(self.current_time))

    def save_object(self, obj, filename):
        with open(filename, 'wb') as output:  # Overwrites any existing file.
            pickle.dump(obj, output, pickle.HIGHEST_PROTOCOL)
        output.close()
        print("Scraper saved successfully!")

    def graph_sentiment(self, graph_setup, x, y, sentiment):
        if len(graph_setup) == 0:
            plt.ion()
            plt.figure(figsize=(10, 5))
            graph_setup.append('Created Graph')
        now = datetime.datetime.now()
        sentiment_label = ['BTC', 'ETH', 'EOS', 'LTC', 'XRP', 'BCH',
                           'ETC', 'XMR', 'ZEC', 'QTUM', 'NEO',
                           'TRX', 'BTM', 'KEY', 'TRUE', 'XUC', 'XLM', 'DASH',
                           'USDT', 'BTS', 'BIX', 'OMG', 'AST', 'UBTC', 'WPR', 'BNB',
                           'PAX', 'ZRX', 'HSR', 'RVN', 'ADA', 'OKB', 'GTO', 'TUSD',
                           'BAT', 'GVT', 'DOGE', 'DENT', 'XIN', 'MITH', 'PHX',
                           'BCPT', 'GNT', 'SC', 'IOT', 'DLT', 'WTC', 'PAI', 'VET', 'ICX',
                           'NPXS', 'ONT', 'STORM', 'WAVES', 'AE', 'WAN', 'NCASH', 'LSK',
                           'XEM', 'ARN', 'HYDRO', 'ELF', 'APIS', 'IOST', 'MDA', 'DOCK', 'ETF',
                           'XVG', 'ZIL', 'QASH', 'QKC', 'KNC', 'TNT', 'POLY', 'MBT', 'HT', 'MGO',
                           'IOTX', 'SWFTC', 'BLZ', 'BTG', 'PAL', 'DNT', 'INT', 'MFT', 'MTH',
                           'BMX', 'SRN', 'GO', 'BCD', 'NOAH', 'UBEX', 'NAS', 'LINK', 'ZEN', 'MCO',
                           'DGD', 'BBK', 'ABT', 'YOYOW']
        x.append(now)

        y.append(sentiment['Current_sentiment'])

        # for time in now:
        #	x.append(time)

        # for sentiment in sentiment['Current_sentiment']:
        #	y.append(sentiment)

        print(x)
        print(y)
        num_plots = 100
        plt.gca().set_prop_cycle(plt.cycler('color', plt.cm.rainbow(np.linspace(0, 1, num_plots))))
        plt.plot(x, y)
        plt.title('Sentiment Analysis', fontsize=26)
        plt.xlabel('Time', fontsize=18)
        plt.xticks(rotation=45, horizontalalignment="right")
        plt.ylabel('Current Sentiment', fontsize=18)
        plt.legend(labels=sentiment_label, loc='upper left', ncol=3, prop={'size': 6}, labelspacing=0.2,
                   bbox_to_anchor=(1, 1))
        plt.tight_layout()
        plt.pause(0.05)
        plt.draw()

    # def graph_sentiment_2()
    #	self.current

    def run_final_script(self):

        # Get's the data and initializes the variables
        scrapers, curr_sentiment, current_time = self.starter(True)

        graph_x = list()
        graph_y = list()
        graph_setup = list()

        while 1:
            self.c_time = datetime.datetime.now()
            self.st = self.report_start()
            self.st = self.scrape()
            self.isUpdated = self.st
            if self.isUpdated:
                self.save_object(self.st, "scraper_starter_noDB.pkl")
            # time.sleep(900)
            self.st.report_end()
            self.now = datetime.datetime.now()
            print("Time spent:{}".format(self.now - self.c_time))
    # while 1:
    # 	self.c_time = datetime.datetime.now()
    # 	self.report_start()
    # 	# Scrape does everything
    # 	self.st = self.scrape()
    # 	self.isUpdated = self.st
    # 	self.graph_sentiment(graph_setup, graph_x, graph_y, curr_sentiment.sentiment)
    # 	if self.isUpdated:
    # 		self.save_object(self.st, "scraper_starter_noDB.pkl")
    # 		print("Updated")
    # 	#time.sleep(900)
    # 	self.report_end()
    # 	self.now = datetime.datetime.now()
    # 	print("Time spent:{}".format(self.now - self.c_time))

import speech_recognition as sr
import pyaudio as pa
import wave
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
# what to do if we have multiple audio sources (multiple browsers open)
# accuracy of speech recognition not 100%
import speech_recognition as sr

# obtain audio from the microphone


one_min_timer = time.time()
three_min_timer = time.time()
five_min_timer = time.time()
fifteen_min_timer = time.time()
thirty_min_timer = time.time()


def mic():
    analyzer = SentimentIntensityAnalyzer()
    r = sr.Recognizer()
    r.energy_threshold = 400
    r.dynamic_energy_threshold = False
    mic = sr.Microphone(device_index=1)      #change device_index to local machine stereo mix index
    currencies = ['Bitcoin','ethereum','Litecoin','Bitcoin cash','ethereum classic','Monero',
                  'zcash','Tron','Bytom','selfkey','truechain','exchange Union','Stellar',
                  'cardano','tether','bitshares','bibox coin','OmiseGo','airswap','United Bitcoin',
                  'wepower','binance coin','paxos standard','0x','h-share','ravencoin','Cardano',
                  'okex','GIFTO','true USD','basic attention token','Genesis Vision','Dogecoin',
                  'Innity Economics','mithril','red pulse Phoenix','blockmason credit protocol',
                  'Golem Network token','siacoin','iota','agrello Delta','waltonchain','Project Pai',
                  'vechain','icon project','pundi X','ontology','aeternity','wanchain','nucleus vision',
                  'Lisk','nem','Aeron','hydrogen','aelf','iOS token','Moeda','dock. IO','ethereum fog',
                  'Verge','zilliqa','Quoine Liquid','quarkchain','kyber Network','tierion','polymath Network',
                  'multi bot','Huobi Token','MobileGo','IoTeX Network','SwftCoin','bluzelle','Bitcoin gold',
                  'policypal Network','district0x','internet node token','Mainframe','monetha','bitmart coin',
                  'Sirin labs','go chain','Bitcoin diamond','Noah coin','nebulas','chain link','Horizen','crypto.com',
                  'digixdao','bit blocks','Arc block']

    currens = {'Bitcoin': [],'ethereum': [],'Litecoin': [],'Bitcoin cash': [],'ethereum classic': [],'Monero': [],
                  'zcash': [],'Tron': [],'Bytom': [],'selfkey': [],'truechain': [],
                  'exchange Union': [],'Stellar': [],'cardano': [],'tether': [],'bitshares': [],'bibox coin': [],
                  'OmiseGo': [],'airswap': [],'United Bitcoin': [],'wepower': [],'binance coin': [],
                  'paxos standard': [],'0x': [],'h-share': [],'ravencoin': [],'Cardano': [],'okex': [],
                  'GIFTO': [],'true USD': [],'basic attention token': [],'Genesis Vision': [],'Dogecoin': [],
                  'Innity Economics': [],'mithril': [],'red pulse Phoenix': [],'blockmason credit protocol': [],
                  'Golem Network token': [],'siacoin': [],'iota': [],'agrello Delta': [],'waltonchain': [],
                  'Project Pai': [],'vechain': [],'icon project': [],'pundi X': [],'ontology': [],'aeternity': [],
                  'wanchain': [],'nucleus vision': [],'Lisk': [],'nem': [],'Aeron': [],'hydrogen':[],'aelf': [],
                  'iOS token': [],'Moeda': [],'dock. IO': [],'ethereum fog': [],'Verge': [],'zilliqa': [],
                  'Quoine Liquid': [],'quarkchain': [],'kyber Network': [],'tierion': [],'polymath Network': [],
                  'multi bot': [],'Huobi Token': [],'MobileGo': [],'IoTeX Network': [],'SwftCoin': [],'bluzelle': [],
                  'Bitcoin gold': [],'policypal Network': [],'district0x': [],'internet node token': [],'Mainframe': [],
                  'monetha': [],'bitmart coin': [],'Sirin labs': [],'go chain': [],'Bitcoin diamond': [],
                  'Noah coin': [],'nebulas': [],'chain link': [],'Horizen': [],'crypto.com': [],'digixdao': [],
                  'bit blocks': [],'Arc block': []}

    one_min = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [],
                'red pulse Phoenix': [], 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [],
                'iota': [], 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [],
                'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [],
                'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
                'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
                'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
                'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
                'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
                'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
                'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [], 'chain link': [],
                'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [], 'Arc block': []}

    three_min = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
               'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
               'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
               'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
               'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
               'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
               'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [],
               'red pulse Phoenix': [], 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [],
               'iota': [], 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [],
               'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [],
               'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
               'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
               'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
               'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
               'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
               'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
               'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [], 'chain link': [],
               'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [], 'Arc block': []}

    five_min = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
               'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
               'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
               'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
               'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
               'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
               'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [],
               'red pulse Phoenix': [], 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [],
               'iota': [], 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [],
               'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [],
               'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
               'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
               'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
               'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
               'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
               'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
               'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [], 'chain link': [],
               'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [], 'Arc block': []}

    fifteen_min = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
               'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
               'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
               'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
               'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
               'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
               'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [],
               'red pulse Phoenix': [], 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [],
               'iota': [], 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [],
               'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [],
               'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
               'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
               'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
               'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
               'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
               'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
               'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [], 'chain link': [],
               'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [], 'Arc block': []}

    thirty_min = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
               'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
               'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
               'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
               'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
               'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
               'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [],
               'red pulse Phoenix': [], 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [],
               'iota': [], 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [],
               'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [],
               'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
               'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
               'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
               'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
               'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
               'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
               'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [], 'chain link': [],
               'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [], 'Arc block': []}


    one_hour = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [],
                'red pulse Phoenix': [], 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [],
                'iota': [], 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [],
                'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [],
                'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
                'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
                'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
                'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
                'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
                'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
                'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [], 'chain link': [],
                'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [], 'Arc block': []}

    two_hour = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [],
                'red pulse Phoenix': [], 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [],
                'iota': [], 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [],
                'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [],
                'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
                'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
                'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
                'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
                'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
                'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
                'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [], 'chain link': [],
                'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [], 'Arc block': []}


    four_hour = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [],
                'red pulse Phoenix': [], 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [],
                'iota': [], 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [],
                'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [],
                'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
                'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
                'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
                'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
                'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
                'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
                'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [], 'chain link': [],
                'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [], 'Arc block': []}


    six_hour = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [], 'Monero': [],
                'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [], 'exchange Union': [],
                'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [],
                'wepower': [], 'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [],
                'ravencoin': [], 'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [],
                'basic attention token': [], 'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [],
                'mithril': [], 'red pulse Phoenix': [], 'blockmason credit protocol': [],
                'Golem Network token': [], 'siacoin': [], 'iota': [], 'agrello Delta': [], 'waltonchain': [],
                'Project Pai': [], 'vechain': [], 'icon project': [], 'pundi X': [], 'ontology': [],
                'aeternity': [], 'wanchain': [], 'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [],
                'hydrogen': [], 'aelf': [], 'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [],
                'Verge': [], 'zilliqa': [], 'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [],
                'tierion': [], 'polymath Network': [], 'multi bot': [], 'Huobi Token': [], 'MobileGo': [],
                'IoTeX Network': [], 'SwftCoin': [], 'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [],
                'district0x': [], 'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [],
                'Sirin labs': [], 'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [],
                'chain link': [], 'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [],
                'Arc block': []}

    twelve_hour = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                   'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                   'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                   'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                   'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                   'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                   'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [], 'red pulse Phoenix': [],
                   'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [], 'iota': [],
                   'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [], 'icon project': [],
                   'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [], 'nucleus vision': [], 'Lisk': [],
                   'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [], 'iOS token': [], 'Moeda': [], 'dock. IO': [],
                   'ethereum fog': [], 'Verge': [], 'zilliqa': [], 'Quoine Liquid': [], 'quarkchain': [],
                   'kyber Network': [], 'tierion': [], 'polymath Network': [], 'multi bot': [], 'Huobi Token': [],
                   'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [], 'bluzelle': [], 'Bitcoin gold': [],
                   'policypal Network': [], 'district0x': [], 'internet node token': [], 'Mainframe': [],
                   'monetha': [], 'bitmart coin': [], 'Sirin labs': [], 'go chain': [], 'Bitcoin diamond': [],
                   'Noah coin': [], 'nebulas': [], 'chain link': [], 'Horizen': [], 'crypto.com': [],
                   'digixdao': [], 'bit blocks': [], 'Arc block': []}

    one_day = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
               'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
               'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
               'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
               'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [],
               'ravencoin': [], 'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [],
               'basic attention token': [], 'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [],
               'mithril': [], 'red pulse Phoenix': [], 'blockmason credit protocol': [],
               'Golem Network token': [], 'siacoin': [], 'iota': [], 'agrello Delta': [], 'waltonchain': [],
               'Project Pai': [], 'vechain': [], 'icon project': [], 'pundi X': [], 'ontology': [],
               'aeternity': [], 'wanchain': [], 'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [],
               'hydrogen': [], 'aelf': [], 'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [],
               'Verge': [], 'zilliqa': [], 'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [],
               'tierion': [], 'polymath Network': [], 'multi bot': [], 'Huobi Token': [], 'MobileGo': [],
               'IoTeX Network': [], 'SwftCoin': [], 'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [],
               'district0x': [], 'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [],
               'Sirin labs': [], 'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [],
               'chain link': [], 'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [],
               'Arc block': []}

    one_week = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'true chain': [],
                'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [], 'red pulse Phoenix': [],
                'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [], 'iota': [],
                'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [], 'icon project': [],
                'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [], 'nucleus vision': [], 'Lisk': [],
                'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [], 'iOS token': [], 'Moeda': [], 'dock. IO': [],
                'ethereum fog': [], 'Verge': [], 'zilliqa': [], 'Quoine Liquid': [], 'quarkchain': [],
                'kyber Network': [], 'tierion': [], 'polymath Network': [], 'multi bot': [], 'Huobi Token': [],
                'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [], 'bluzelle': [], 'Bitcoin gold': [],
                'policypal Network': [], 'district0x': [], 'internet node token': [], 'Mainframe': [],
                'monetha': [], 'bitmart coin': [], 'Sirin labs': [], 'go chain': [], 'Bitcoin diamond': [],
                'Noah coin': [], 'nebulas': [], 'chain link': [], 'Horizen': [], 'crypto.com': [], 'digixdao': [],
                'bit blocks': [], 'Arc block': []}

    one_month = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                 'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                 'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                 'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                 'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                 'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                 'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [], 'red pulse Phoenix': [],
                 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [], 'iota': [],
                 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [], 'icon project': [],
                 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [], 'nucleus vision': [], 'Lisk': [],
                 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [], 'iOS token': [], 'Moeda': [], 'dock. IO': [],
                 'ethereum fog': [], 'Verge': [], 'zilliqa': [], 'Quoine Liquid': [], 'quarkchain': [],
                 'kyber Network': [], 'tierion': [], 'polymath Network': [], 'multi bot': [], 'Huobi Token': [],
                 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [], 'bluzelle': [], 'Bitcoin gold': [],
                 'policypal Network': [], 'district0x': [], 'internet node token': [], 'Mainframe': [], 'monetha': [],
                 'bitmart coin': [], 'Sirin labs': [], 'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [],
                 'nebulas': [], 'chain link': [], 'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [],
                 'Arc block': []}

    three_month = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                   'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                   'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                   'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                   'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                   'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                   'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [], 'red pulse Phoenix': [],
                   'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [], 'iota': [],
                   'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [], 'icon project': [],
                   'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [], 'nucleus vision': [], 'Lisk': [],
                   'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [], 'iOS token': [], 'Moeda': [], 'dock. IO': [],
                   'ethereum fog': [], 'Verge': [], 'zilliqa': [], 'Quoine Liquid': [], 'quarkchain': [],
                   'kyber Network': [], 'tierion': [], 'polymath Network': [], 'multi bot': [], 'Huobi Token': [],
                   'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [], 'bluzelle': [], 'Bitcoin gold': [],
                   'policypal Network': [], 'district0x': [], 'internet node token': [], 'Mainframe': [],
                   'monetha': [], 'bitmart coin': [], 'Sirin labs': [], 'go chain': [], 'Bitcoin diamond': [],
                   'Noah coin': [], 'nebulas': [], 'chain link': [], 'Horizen': [], 'crypto.com': [], 'digixdao': [],
                   'bit blocks': [], 'Arc block': []}

    six_month = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                 'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                 'exchange Union': [], 'Stellar': [], 'cardano': [], 'tether': [], 'bitshares': [],
                 'bibox coin': [], 'OmiseGo': [], 'airswap': [], 'United Bitcoin': [], 'wepower': [],
                 'binance coin': [], 'paxos standard': [], '0x': [], 'h-share': [], 'ravencoin': [],
                 'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [], 'basic attention token': [],
                 'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [], 'mithril': [], 'red pulse Phoenix': [],
                 'blockmason credit protocol': [], 'Golem Network token': [], 'siacoin': [], 'iota': [],
                 'agrello Delta': [], 'waltonchain': [], 'Project Pai': [], 'vechain': [], 'icon project': [],
                 'pundi X': [], 'ontology': [], 'aeternity': [], 'wanchain': [], 'nucleus vision': [],
                 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [], 'iOS token': [], 'Moeda': [],
                 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [], 'Quoine Liquid': [],
                 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
                 'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
                 'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
                 'internet node token': [], 'Mainframe': [],
                 'monetha': [], 'bitmart coin': [], 'Sirin labs': [], 'go chain': [], 'Bitcoin diamond': [],
                 'Noah coin': [], 'nebulas': [], 'chain link': [], 'Horizen': [], 'crypto.com': [], 'digixdao': [],
                 'bit blocks': [], 'Arc block': []}

    one_year = {'Bitcoin': [], 'ethereum': [], 'Litecoin': [], 'Bitcoin cash': [], 'ethereum classic': [],
                'Monero': [], 'zcash': [], 'Tron': [], 'Bytom': [], 'selfkey': [], 'truechain': [],
                'exchange Union': [], 'Stellar': [],
                'cardano': [], 'tether': [], 'bitshares': [], 'bibox coin': [], 'OmiseGo': [], 'airswap': [],
                'United Bitcoin': [], 'wepower': [], 'binance coin': [], 'paxos standard': [], '0x': [],
                'h-share': [], 'ravencoin': [], 'Cardano': [], 'okex': [], 'GIFTO': [], 'true USD': [],
                'basic attention token': [], 'Genesis Vision': [], 'Dogecoin': [], 'Innity Economics': [],
                'mithril': [], 'red pulse Phoenix': [], 'blockmason credit protocol': [],
                'Golem Network token': [], 'siacoin': [], 'iota': [], 'agrello Delta': [], 'waltonchain': [],
                'Project Pai': [], 'vechain': [], 'icon project': [], 'pundi X': [], 'ontology': [], 'aeternity': [],
                'wanchain': [],
                'nucleus vision': [], 'Lisk': [], 'nem': [], 'Aeron': [], 'hydrogen': [], 'aelf': [],
                'iOS token': [], 'Moeda': [], 'dock. IO': [], 'ethereum fog': [], 'Verge': [], 'zilliqa': [],
                'Quoine Liquid': [], 'quarkchain': [], 'kyber Network': [], 'tierion': [], 'polymath Network': [],
                'multi bot': [], 'Huobi Token': [], 'MobileGo': [], 'IoTeX Network': [], 'SwftCoin': [],
                'bluzelle': [], 'Bitcoin gold': [], 'policypal Network': [], 'district0x': [],
                'internet node token': [], 'Mainframe': [], 'monetha': [], 'bitmart coin': [], 'Sirin labs': [],
                'go chain': [], 'Bitcoin diamond': [], 'Noah coin': [], 'nebulas': [],
                'chain link': [], 'Horizen': [], 'crypto.com': [], 'digixdao': [], 'bit blocks': [],
                'Arc block': []}

    # add for aspect
    stopwords = ["shouldn't", 'yourselves', 'll', 'what', 'where', 'few', "you've", 'over', "don't", 'i', 'all', 'can', 'weren', 'of', 'these', 'a', 'now', 'she', 'as', 'why', 'has', 'having', 'or', 'shan', 'herself', 'if', 'does', 'down', 'you', 'but', 'through', "wouldn't", 'same', 'don', 'isn', 'wouldn', 'above', 'more', 'while', 'before', 'up', 'not', "isn't", 'ain', 'until', 'any', 'nor', 'won', 'doesn', 'to', 'from', 've', 'off', 'just', "mightn't", 'ma', 'no', 'under', 'y', 'between', 'didn', 'the', 'yourself', "hadn't", 'we', 'too', 'yours', 'than', 't', 'such', "hasn't", 'do', "you'd", 'my', 'both', 'will', 'again', 'it', 
'is', 'who', 'had', 'needn', 'those', 'have', 'against', "should've", 'they', 'should', 'mustn', "aren't", 'some', 's', 'at', 'themselves', "doesn't", 'itself', 'their', 'haven', 'myself', "couldn't", 'here', 'o', 'me', "it's", 'ours', 'about', 'this', 'doing', 'how', 'further', 'couldn', "mustn't", "that'll", 'in', 'so', 'her', 'which', 'because', 'wasn', 'be', "needn't", "didn't", 'aren', 'hers', 'd', 'once', 'each', "you're", 'our', 'them', 'was', 'own', 're', 'theirs', 'during', "won't", 'he', 'very', 'for', 'its', 'other', 
'himself', "she's", 'being', 'an', 'did', 'into', 'shouldn', 'your', "you'll", 'are', 'there', 'his', 'then', 'mightn', 'm', "haven't", 'by', 'that', 'below', 'hasn', 'ourselves', 'with', 'hadn', "shan't", 'out', 'on', "wasn't", 'after', 'when', 'am', 'most', "weren't", 'been', 'whom', 'and', 'only', 'were', 'him']

    currens_aspect = {'Bitcoin': [],'ethereum': [],'Litecoin': [],'Bitcoin cash': [],'ethereum classic': [],'Monero': [],
                  'zcash': [],'Tron': [],'Bytom': [],'selfkey': [],'truechain': [],
                  'exchange Union': [],'Stellar': [],'cardano': [],'tether': [],'bitshares': [],'bibox coin': [],
                  'OmiseGo': [],'airswap': [],'United Bitcoin': [],'wepower': [],'binance coin': [],
                  'paxos standard': [],'0x': [],'h-share': [],'ravencoin': [],'Cardano': [],'okex': [],
                  'GIFTO': [],'true USD': [],'basic attention token': [],'Genesis Vision': [],'Dogecoin': [],
                  'Innity Economics': [],'mithril': [],'red pulse Phoenix': [],'blockmason credit protocol': [],
                  'Golem Network token': [],'siacoin': [],'iota': [],'agrello Delta': [],'waltonchain': [],
                  'Project Pai': [],'vechain': [],'icon project': [],'pundi X': [],'ontology': [],'aeternity': [],
                  'wanchain': [],'nucleus vision': [],'Lisk': [],'nem': [],'Aeron': [],'hydrogen':[],'aelf': [],
                  'iOS token': [],'Moeda': [],'dock. IO': [],'ethereum fog': [],'Verge': [],'zilliqa': [],
                  'Quoine Liquid': [],'quarkchain': [],'kyber Network': [],'tierion': [],'polymath Network': [],
                  'multi bot': [],'Huobi Token': [],'MobileGo': [],'IoTeX Network': [],'SwftCoin': [],'bluzelle': [],
                  'Bitcoin gold': [],'policypal Network': [],'district0x': [],'internet node token': [],'Mainframe': [],
                  'monetha': [],'bitmart coin': [],'Sirin labs': [],'go chain': [],'Bitcoin diamond': [],
                  'Noah coin': [],'nebulas': [],'chain link': [],'Horizen': [],'crypto.com': [],'digixdao': [],
                  'bit blocks': [],'Arc block': []}

    getAudioDevices()

    # print(mic.device_index)

    #this dataframe updates and stores each currencies' mean scores based on various timestamps
    #a mean score is the average of all the sentiments for a paticular currency within a particular dictionary
    #eg six_hour = {'Bitcoin': [.43,.543,487],'Litecoin': [.65,.58],'ethereum': [.333,.386,.32,.36],}
    def update_sents(string):
        sa = SentimentIntensityAnalyzer()
        score = sa.polarity_scores(string)['compound']
        global one_min_timer
        global three_min_timer
        global five_min_timer
        global fifteen_min_timer
        global thirty_min_timer
        end_timer = time.time()
        one_min_range = end_timer - one_min_timer
        three_min_range = end_timer - three_min_timer
        five_min_range = end_timer - five_min_timer
        fifteen_min_range = end_timer - fifteen_min_timer
        thirty_min_range = end_timer - thirty_min_timer
        t = time.gmtime()
        df = pd.DataFrame(columns=['Currency/Company'])
        df['Currency/Company'] = ['Bitcoin', 'ethereum', 'Litecoin', 'Bitcoin cash', 'ethereum classic','Monero',
                                  'zcash', 'Tron', 'Bytom', 'selfkey', 'truechain','exchange Union',
                                  'Stellar','cardano', 'tether', 'bitshares', 'bibox coin', 'OmiseGo', 'airswap',
                                  'United Bitcoin','wepower', 'binance coin', 'paxos standard', '0x',
                                  'h-share','ravencoin', 'Cardano','okex', 'GIFTO', 'true USD','basic attention token',
                                  'Genesis Vision','Dogecoin','Innity Economics','mithril', 'red pulse Phoenix',
                                  'blockmason credit protocol','Golem Network token', 'siacoin', 'iota',
                                  'agrello Delta', 'waltonchain','Project Pai','vechain', 'icon project', 'pundi X',
                                  'ontology', 'aeternity', 'wanchain','nucleus vision','Lisk', 'nem', 'Aeron',
                                  'hydrogen', 'aelf','iOS token', 'Moeda','dock. IO', 'ethereum fog','Verge',
                                  'zilliqa','Quoine Liquid', 'quarkchain', 'kyber Network','tierion',
                                  'polymath Network','multi bot','Huobi Token', 'MobileGo', 'IoTeX Network',
                                  'SwftCoin','bluzelle', 'Bitcoin gold','policypal Network', 'district0x',
                                  'internet node token','Mainframe','monetha', 'bitmart coin','Sirin labs',
                                  'go chain', 'Bitcoin diamond', 'Noah coin', 'nebulas','chain link',
                                  'Horizen', 'crypto.com','digixdao', 'bit blocks','Arc block']
        current_col = []
        one_min_col = []
        three_min_col = []
        five_min_col = []
        fifteen_min_col = []
        thirty_min_col = []
        one_hour_col = []
        two_hour_col = []
        four_hour_col = []
        six_hour_col = []
        twelve_hour_col = []
        one_day_col = []
        one_week_col = []
        one_month_col = []
        three_month_col = []
        six_month_col = []
        one_year_col = []

        # Aspect Sentiment 2/19/2020
        current_aspect = pd.DataFrame()
        one_min_aspect = []
        three_min_aspect = []
        five_min_aspect = []
        fifteen_min_aspect = []
        thirty_min_aspect = []
        one_hour_aspect = []
        two_hour_aspect = []
        four_hour_aspect = []
        six_hour_aspect = []
        twelve_hour_aspect = []
        one_day_aspect = []
        one_week_aspect = []
        one_month_aspect = []
        three_month_aspect = []
        six_month_aspect = []
        one_year_aspect = []

        for k in currens_aspect.items():
            if k[0] in string:
                querywords = string.split()
                resultwords  = [word for word in querywords if word.lower() not in stopwords]
                result = ' '.join(resultwords)
                querywords = string.split()
                resultwords  = [word for word in querywords if word.lower() not in currencies]
                result = ' '.join(resultwords)
                score = analyzer.polarity_scores(result)['compound']
                k[1].append(score)
        for k in currens.items():
            if len(k[1]) > 0:
                temp_df = {'aspect': k[0], 'value': k[1]}
                df = pd.DataFrame([temp_df])
                frames = [current_aspect, df]
                end = pd.concat(frames)
                current_aspect = end

        # Current Sentiments - the 'currens' dict will never reset.
        #It will always hold the four most current sentiments
        for k in currens.items():
            if k[0] in string:
                if len(k[1]) > 3:
                    k[1].append(score)
                    k[1].pop(0)
                    three_avg = np.mean(k[1])
                    current_col.append(three_avg)
                    
                    #df['Current'] = current_col
                    #print(current_col)
                elif len(k[1]) == 0:
                    k[1].append(score)
                    two_avg = np.mean(k[1])
                    current_col.append(two_avg)
                    #print(current_col)
                    # print(k, two_avg)
                else:
                    k[1].append(score)
                    one_avg = np.mean(k[1])
                    current_col.append(one_avg)
                    #print(current_col)
                    # print(k, one_avg)


            else:
                if len(k[1]) == 0:
                    current_col.append('NaN')
                    #print(current_col)
                else:
                    four_avg = np.mean(k[1])
                    current_col.append(four_avg)
                    #print(current_col)



        # One Min Sentiments - the 'one_min' dict will reset every min
        for k in one_min.items():
            if one_min_range > 60:
                k[1].clear()
                one_min_col.append('NaN')
                one_min_timer = time.time()
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_min_col.append(avg)
                    else:
                        one_min_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_min_col.append(avg)
                    else:
                        one_min_col.append('NaN')



        # Three Min Sentiments - the 'three_min' dict will reset every three min
        for k in three_min.items():
            if three_min_range > 180:
                k[1].clear()
                three_min_col.append('NaN')
                three_min_timer = time.time()
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        three_min_col.append(avg)
                    else:
                        three_min_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        three_min_col.append(avg)
                    else:
                        three_min_col.append('NaN')



        #Five Min Sentiments - the 'five_min' dict will reset every five min
        for k in five_min.items():
            if five_min_range > 300:
                k[1].clear()
                five_min_col.append('NaN')
                five_min_timer = time.time()
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        five_min_col.append(avg)
                    else:
                        five_min_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        five_min_col.append(avg)
                    else:
                        five_min_col.append('NaN')


        ##Fifteen Min Sentiments - the 'fifteen_min' dict will reset every fifteen min
        for k in fifteen_min.items():
            if fifteen_min_range > 900:
                k[1].clear()
                fifteen_min_col.append('NaN')
                fifteen_min_timer = time.time()
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        fifteen_min_col.append(avg)
                    else:
                        fifteen_min_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        fifteen_min_col.append(avg)
                    else:
                        fifteen_min_col.append('NaN')


        #Thirty Min Sentiments - the 'thirty_min' dict will reset every thirty min
        for k in thirty_min.items():
            if thirty_min_range > 1800:
                k[1].clear()
                thirty_min_col.append('NaN')
                thirty_min_timer = time.time()
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        thirty_min_col.append(avg)
                    else:
                        thirty_min_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        thirty_min_col.append(avg)
                    else:
                        thirty_min_col.append('NaN')




        # One Hour Sentiments - the 'one_hour' dict will reset every hour
        for k in one_hour.items():
            if (t[3] == 0 and t[4] == 0) or \
                    (t[3] == 1 and t[4] == 0) or \
                    (t[3] == 2 and t[4] == 0) or \
                    (t[3] == 3 and t[4] == 0) or \
                    (t[3] == 4 and t[4] == 0) or \
                    (t[3] == 5 and t[4] == 0) or \
                    (t[3] == 6 and t[4] == 0) or \
                    (t[3] == 7 and t[4] == 0) or \
                    (t[3] == 8 and t[4] == 0) or \
                    (t[3] == 9 and t[4] == 0) or \
                    (t[3] == 10 and t[4] == 0) or \
                    (t[3] == 11 and t[4] == 0) or \
                    (t[3] == 12 and t[4] == 0) or \
                    (t[3] == 13 and t[4] == 0) or \
                    (t[3] == 14 and t[4] == 0) or \
                    (t[3] == 15 and t[4] == 0) or \
                    (t[3] == 16 and t[4] == 0) or \
                    (t[3] == 17 and t[4] == 0) or \
                    (t[3] == 18 and t[4] == 0) or \
                    (t[3] == 19 and t[4] == 0) or \
                    (t[3] == 20 and t[4] == 0) or \
                    (t[3] == 21 and t[4] == 0) or \
                    (t[3] == 22 and t[4] == 0) or \
                    (t[3] == 23 and t[4] == 0):
                k[1].clear()
                one_hour_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_hour_col.append(avg)
                    else:
                        one_hour_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_hour_col.append(avg)
                    else:
                        one_hour_col.append('NaN')


        ## One Hour Sentiments - the 'one_hour' dict will reset every hour
        for k in two_hour.items():
            if (t[3] == 0 and t[4] == 0) or \
                    (t[3] == 2 and t[4] == 0) or \
                    (t[3] == 4 and t[4] == 0) or \
                    (t[3] == 6 and t[4] == 0) or \
                    (t[3] == 8 and t[4] == 0) or \
                    (t[3] == 10 and t[4] == 0) or \
                    (t[3] == 12 and t[4] == 0) or \
                    (t[3] == 14 and t[4] == 0) or \
                    (t[3] == 16 and t[4] == 0) or \
                    (t[3] == 18 and t[4] == 0) or \
                    (t[3] == 20 and t[4] == 0) or \
                    (t[3] == 23 and t[4] == 0):
                k[1].clear()
                two_hour_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        two_hour_col.append(avg)
                    else:
                        two_hour_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        two_hour_col.append(avg)
                    else:
                        two_hour_col.append('NaN')


        # Four Hour Sentiments - the 'four_hour' dict will reset every four hours
        for k in four_hour.items():
            if (t[3] == 0 and t[4] == 0) or \
                    (t[3] == 4 and t[4] == 0) or \
                    (t[3] == 8 and t[4] == 0) or \
                    (t[3] == 12 and t[4] == 0) or \
                    (t[3] == 16 and t[4] == 0) or \
                    (t[3] == 20 and t[4] == 0):
                k[1].clear()
                four_hour_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        four_hour_col.append(avg)
                    else:
                        four_hour_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        four_hour_col.append(avg)
                    else:
                        four_hour_col.append('NaN')




        # Six Hour Sentiments - the 'six_hour' dict will reset every six hours
        for k in six_hour.items():
            if (t[3] == 0 and t[4] == 0) or \
                    (t[3] == 6 and t[4] == 0) or \
                    (t[3] == 12 and t[4] == 0) or \
                    (t[3] == 18 and t[4] == 0):
                k[1].clear()
                six_hour_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        six_hour_col.append(avg)
                    else:
                        six_hour_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        six_hour_col.append(avg)
                    else:
                        six_hour_col.append('NaN')



        # Twelve Hour Sentiments - the 'twelve_hour' dict will reset every twelve hours
        for k in twelve_hour.items():
            if (t[3] == 0 and t[4] == 0) or \
                    (t[3] == 12 and t[4] == 0):
                k[1].clear()
                twelve_hour_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        twelve_hour_col.append(avg)
                    else:
                        twelve_hour_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        twelve_hour_col.append(avg)
                    else:
                        twelve_hour_col.append('NaN')



        # One Day Sentiments - the 'one_day' dict will reset every day
        for k in one_day.items():
            if (t[3] == 0 and t[4] == 0):
                k[1].clear()
                one_day_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_day_col.append(avg)
                    else:
                        one_day_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_day_col.append(avg)
                    else:
                        one_day_col.append('Nan')


        # One Week Sentiments - the 'one_week' dict will reset every week
        for k in one_week.items():
            if t[6] == 0 and (t[3] == 0 and t[4] == 0):
                k[1].clear()
                one_week_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_week_col.append(avg)
                    else:
                        one_week_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_week_col.append(avg)
                    else:
                        one_week_col.append('NaN')


        # One Month Sentiments - the 'one_month' dict will reset every month
        for k in one_month.items():
            if (t[1] == 1 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 2 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 3 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 4 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 5 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 6 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 7 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 8 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 9 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 10 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 11 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 12 and t[2] == 1 and t[3] == 0 and t[4] == 0):
                k[1].clear()
                one_month_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_month_col.append(avg)
                    else:
                        one_month_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_month_col.append(avg)
                    else:
                        one_month_col.append('NaN')


        # Three Month Sentiments - the 'three_month' dict will reset every three months
        for k in three_month.items():
            if (t[1] == 3 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 6 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 9 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 12 and t[2] == 1 and t[3] == 0 and t[4] == 0):
                k[1].clear()
                three_month_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        three_month_col.append(avg)
                    else:
                        three_month_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        three_month_col.append(avg)
                    else:
                        three_month_col.append('NaN')


        # Six Month Sentiments - the 'six_month' dict will reset every six months
        for k in six_month.items():
            if (t[1] == 6 and t[2] == 1 and t[3] == 0 and t[4] == 0) or \
                    (t[1] == 12 and t[2] == 1 and t[3] == 0 and t[4] == 0):
                k[1].clear()
                six_month_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        six_month_col.append(avg)
                    else:
                        six_month_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        six_month_col.append(avg)
                    else:
                        six_month_col.append('NaN')


        # One Year Sentiments - the 'one_year' dict will reset every year
        for k in one_year.items():
            if (t[1] == 12 and t[2] == 1 and t[3] == 0 and t[4] == 0):
                k[1].clear()
                one_year_col.append('NaN')
            else:
                if k[0] in string:
                    k[1].append(score)
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_year_col.append(avg)
                    else:
                        one_year_col.append('NaN')
                else:
                    if len(k[1]) > 0:
                        avg = np.mean(k[1])
                        one_year_col.append(avg)
                    else:
                        one_year_col.append('NaN')




        df['Current'] = current_col
        df['One Min'] = one_min_col
        df['Three Min'] = three_min_col
        df['Five Min'] = five_min_col
        df['Fifteen Min'] = fifteen_min_col
        df['Thirty Min'] = thirty_min_col
        df['One Hour'] = one_hour_col
        df['Two Hours'] = two_hour_col
        df['Four Hours'] = four_hour_col
        df['Six Hours'] = six_hour_col
        df['Twelve Hours'] = twelve_hour_col
        df['One Day'] = one_day_col
        df['One Week'] = one_week_col
        df['One Month'] = one_month_col
        df['Three Months'] = three_month_col
        df['Six Months'] = six_month_col
        df['One Year'] = one_year_col



        print(df)


    try:
        while True:
            print('Recording...')
            #one_min_timer = time.time()
            t = time.gmtime()
            #print(t)
            with mic as source:
                audio = r.listen(source, timeout=15, phrase_time_limit=10)
            try:
                speech_text = r.recognize_google(audio)
            except sr.WaitTimeoutError as e:
                print("Timeout; {0}".format(e))
            except sr.RequestError:
                print('API unavailable')
            except sr.UnknownValueError:
                speech_text = 0
                print('Unable to recognize speech')

            #speech_text = r.recognize_google(audio)
            #if len(speech_text) <= 0:
            #    return 'end'

            print('Recording ended.')

            #try:
            try:
                if len(speech_text) > 0:
                     print(' '+ speech_text)
                     #print(type(speech_text))
                     update_sents(speech_text)
                     #print(current_col)
                     #print(df)
                     #for c in currencies:
                         #if c in speech_text:
                            #print('Current Sentiment Score')
                            #print(c, '->', analyzer.polarity_scores(speech_text)['compound'])
            except sr.WaitTimeoutError as e:
                print("Timeout; {0}".format(e))
            except:
                print('I heard nothing')
                return
    except sr.WaitTimeoutError as e:
        print("Timeout; {0}".format(e))
    except KeyboardInterrupt:
        print('nothing happened')
        pass


# gets stereo mix device index
def getAudioDevices():
    p = pa.PyAudio()
    for index, name in enumerate(sr.Microphone.list_microphone_names()):
        print("Microphone with name \"{1}\" found for `Microphone(device_index={0})`".format(index, name))


#getAudioDevices()


mic()





# This needs to run the code in the first place
if __name__ == "__main__":
    sentiment_analyzer = Sentiment()
    sentiment_analyzer.run_final_script()
