# Regular Imports
import argparse
from collections import defaultdict
from datetime import datetime
import time
import random
import torch
import os
import pandas as pd
import pickle
import ccxt
import logging
# import Sentiment_Analysis_Testing as SA
import pickle
import numpy as np
import fxtrader as fx

# In this method if scrapeNow is passed as False then make sure there is already a
# # pickel file scraper_starter_noDB.pkl with sentiment details
# def sentimentOfCoin(coin, scrapeNow):
#     if(scrapeNow):
#         sentiment_analyzer = SA.Sentiment()
#         sentiment = sentiment_analyzer.run_final_script()
#         for idx in sentiment.index:
#             if (idx == coin):
#                 current_sentiment = sentiment.loc[idx]['Current_sentiment']
#     else:
#         sentiment = pickle.load(open("scraper_starter_noDB.pkl", "rb"))
#         for idx in sentiment.index:
#             if (idx == coin):
#                 current_sentiment = sentiment.loc[idx]['Current_sentiment']
#     return current_sentiment
#
#
# coin = 'BTC'
# current_sentiment = sentimentOfCoin(coin, False)
# print(current_sentiment)


# Custom Imports
from agent import Agent
from env import Env  # env_rainbow was initially env
from memory import ReplayMemory
from test import test
import resample
import takeCut

script_path = os.path.dirname(__file__)

pd.options.mode.chained_assignment = None  # default='warn'

parser = argparse.ArgumentParser(description='Rainbow')
parser.add_argument('--seed', type=int, default=123, help='Random seed')
parser.add_argument('--disable-cuda', default=False, action='store_true', help='Disable CUDA')
parser.add_argument('--game', type=str, default='space_invaders', help='ATARI game')
parser.add_argument('--T-max', type=int, default=int(10000), metavar='STEPS',     #reset default to 10000
                    help='Number of training steps (4x number of frames)')
parser.add_argument('--max-episode-length', type=int, default=int(1000), metavar='LENGTH',
                    help='Max episode length (0 to disable)')
parser.add_argument('--history-length', type=int, default=1, metavar='T', help='Number of consecutive states processed')
parser.add_argument('--hidden-size', type=int, default=32, metavar='SIZE', help='Network hidden size')
parser.add_argument('--noisy-std', type=float, default=0.1, metavar='σ',
                    help='Initial standard deviation of noisy linear layers')
parser.add_argument('--atoms', type=int, default=115, metavar='C', help='Discretised size of value distribution')
parser.add_argument('--V-min', type=float, default=-10, metavar='V', help='Minimum of value distribution support')
parser.add_argument('--V-max', type=float, default=10, metavar='V', help='Maximum of value distribution support')

parser.add_argument('--model', default='btcmodel.pth', type=str, metavar='PARAMS', help='Pretrained model (state dict)')
# parser.add_argument('--model',  type=str, metavar='PARAMS', help='Pretrained model (state dict)')

parser.add_argument('--memory-capacity', type=int, default=int(47910400), metavar='CAPACITY',
                    help='Experience replay memory capacity')
parser.add_argument('--replay-frequency', type=int, default=2, metavar='k', help='Frequency of sampling from memory')
parser.add_argument('--priority-exponent', type=float, default=0.5, metavar='ω',
                    help='Prioritised experience replay exponent (originally denoted α)')
parser.add_argument('--priority-weight', type=float, default=0.4, metavar='β',
                    help='Initial prioritised experience replay importance sampling weight')
parser.add_argument('--multi-step', type=int, default=3, metavar='n', help='Number of steps for multi-step return')
parser.add_argument('--discount', type=float, default=0.99, metavar='γ', help='Discount factor')
parser.add_argument('--target-update', type=int, default=int(100), metavar='τ',
                    help='Number of steps after which to update target network')
parser.add_argument('--reward-clip', type=int, default=0, metavar='VALUE', help='Reward clipping (0 to disable)')
# parser.add_argument('--lr', type=float, default=0.0000625, metavar='η', help='Learning rate')
parser.add_argument('--lr', type=float, default=0.0000625, metavar='η', help='Learning rate')

parser.add_argument('--adam-eps', type=float, default=1.5e-4, metavar='ε', help='Adam epsilon')

parser.add_argument('--batch-size', type=int, default=1, metavar='SIZE', help='Batch size')
parser.add_argument('--learn-start', type=int, default=int(100), metavar='STEPS',
                    help='Number of steps before starting training')
parser.add_argument('--evaluate', action='store_true', default=False, help='Evaluate only')
parser.add_argument('--evaluation-interval', type=int, default=10000, metavar='STEPS',
                    help='Number of training steps between evaluations')
parser.add_argument('--evaluation-episodes', type=int, default=1, metavar='N',
                    help='Number of evaluation episodes to average over')
parser.add_argument('--evaluation-size', type=int, default=500, metavar='N',
                    help='Number of transitions to use for validating Q')
parser.add_argument('--log-interval', type=int, default=1000, metavar='STEPS',
                    help='Number of training steps between logging status')
parser.add_argument('--render', action='store_true', help='Display screen (testing only)')

# Setup
args = parser.parse_args()
print(' ' * 26 + 'Options')
for k, v in vars(args).items():
    print(' ' * 26 + k + ': ' + str(v))

print(args)

random.seed(args.seed)
torch.manual_seed(random.randint(1, 10000))
if torch.cuda.is_available() and not args.disable_cuda:
    args.device = torch.device('cuda')
    torch.cuda.manual_seed(random.randint(1, 10000))
    torch.backends.cudnn.enabled = False  # Disable nondeterministic ops (not sure if critical but better safe than sorry)
else:
    args.device = torch.device('cpu')


class Main_Perfect_Trade():

    def log(s):
        print('[' + str(datetime.now().strftime('%Y-%m-%dT%H:%M:%S')) + '] ' + s)

    @staticmethod
    def load_pickle_data():
        # Loads data from pickle value to be used later
        # Could use CSV to DF values as opposed to pickle. This could then result in
        data_path = os.path.join(script_path, 'BTCUSD-15Min-Data.pkl')
        with open(data_path, 'rb') as handler:
            data_dict = pickle.load(handler)
        return data_dict

    def train_and_predict(data_dict, infinite_training=True):
        # Setup of necessary exchange variables
        #TEST API_KEY AND SECRET DELETE LATER POST TEST!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        exchange = ccxt.binance({'ratelimit': 60000, 'enableRateLimit': True,
                                 'api_key': 'VGuiB0VmDX5jU3PmQuTijNP5zhpnD3CyApeeY9c2zYiT3lxUL8oZxHBFIslxyoWW',
                                 'secret': 'WZJmq6wGlx6QHmPE9IBP4VsHhO1vMroh68sZoTfg5aKy9Md8wB1O2o2VGUEkNRTV',
                                 'options': {'adjustForTimeDifference': True}})

        infinite_training = True
        buyorderstatus = []
        buy_price = 0
        sell_price = 0
        profit_USD = []
        #amount_owned_BTC = Main_Perfect_Trade.fetch_balanace(coin="BTC")  # Fetches BTC amount
        #amount_owned_USD = Main_Perfect_Trade.fetch_balanace(coin="USDT")  # Fetches USD amount
        transanctionHappend = False
        action_comparision = defaultdict(int)
        firstround = True
        start = time.time()
        amount_USD = 100
        amount_BTC = 1
        cal_fee = 0.001  # Change 1
        cal_dict = {}
        pred_data = []  # Change 2
        pred_money = 0
        pred_units = 1

        # Change 3

        def singleTradeCommand(test_prices, price_list, money, units, fee, train_time):
            ''' Converts $ to units on buy or units to $ on sell
            Initiate a transaction between accounts and exchanges
            :param command: 1- buy (valley) 2- sell (peak) 0- no action (neutral)
            :param priceOp: price per unit (open price)
            :return: money and units after trade
            '''
            pred_data = []
            intialMoney = money
            flag = True
            loc = -1
            for i in range(len(price_list)):
                loc += 1
                # priceOp = test_prices[i]['Closing_Price']
                # print(type(test_prices),test_prices.iloc[i,2])
                priceOp = test_prices.iloc[i, 4]
                targetOp = test_prices.iloc[i, 6]
                # priceOp = (test_prices.iloc[i, 2] + test_prices.iloc[i, 3]) / 2
                # print("The iteration - ", timestamp.iloc[i], "Money",money,"Units", units, "Action",price_list[i], "Target", targetOp, "Price at that point", priceOp)
                if int(price_list[i]) < 0 or int(price_list[i]) > 2:
                    pass
                else:
                    action_price_list = int(price_list[loc])
                    pred_data.append(
                        [pd.to_datetime(train_time.iloc[i], unit='ms').to_pydatetime(), action_price_list, targetOp,
                        priceOp, test_prices.iloc[i, 1], test_prices.iloc[i, 4]])

                # s = "Money ${} \t Units {} \t Action {} \t PriceAtThatPoint {} \
                #    ".format(money, units, price_list[i], priceOp)
                # cal_dict[i] = s

                command = price_list[i]
                if (command == 0):
                    # return money, units
                    pass

                elif (command == 1 and not flag):
                    # if (flag == True):
                    # print ("multiple buys in a row, ignoring subsequent calls")
                    # return money, units
                    trans = money * 0.998
                    # print ("trans", trans)
                    feePaid = trans * fee
                    units = (trans - feePaid) / priceOp
                    money = money - trans - feePaid
                    flag = True
                    # print ("buy: ${} {} units".format(money, units))
                    # return money, units

                elif (command == 2 and flag):
                    # if (flag == False):
                    # print ("multiple sells  in a row, ignoring subsequent calls")
                    # return money, units
                    money += units * priceOp * (1 - fee)
                    units = 0
                    flag = False
                    # print ("sell: ${} {} units".format(money, units))
                    # return money, units

                else:
                    pass
                    #print("Invalid Command No. ({})".format(command))
                    # return None, None
            return money, units, pred_data



        # Takes in data pulled from the data_dict -  see load_pickle_data()
        p = 0
        while infinite_training:  # Messy solution, and limits the function to only infinite training but should fix mem issues

            # take cut
            # session = fx.login("DA545354", "Forex123")
            # cash, currency = fx.get_client_margin("DA545354", session)
            #
            # print("Taking Cut: (${}, {}%".format(cash, 20))
            # cash2, cut = takeCut.takeCutPeriodical(cash, 20, 0, 'days', 3)
            # print ("cash: {}, cut: {}".format(cash2, cut))


            try:
                data = data_dict['data']
                label = data_dict['label']
                full_data = data_dict['full_data']
                timestamp = full_data['Timestamp_ms']
                checkdata = pd.DataFrame(full_data,
                                         columns=['Timestamp_ms', 'Open_Price', 'Highest_Price', 'Lowest_Price',
                                                  'Closing_Price', 'Volume', 'traget'])  # full_data

                checkdata.to_csv('Datacheck.csv')
                avg_price = (full_data['Highest_Price'] + full_data['Lowest_Price']) / 2

                # train-test split 70% and 30%
                split = int(.70 * len(data))
                #data_partial = data.iloc[:,0:22]
                #data_partial["Time_stamp"] = timestamp
                #print("eric dp: {}\n{}".format(data_partial["Time_stamp"], data_partial))
                #print("dat_shape", data_partial.shape)
                #print ("---")
                #
                train_data = data.loc[:split]  # Takes the right 99% of data
                train_label = label.loc[:split]
                Traintimestamp = timestamp.loc[:split]



                test_prices = full_data.loc[split:]  # Change 4

                test_data = data.loc[split:]  # Takes the left 1% of data
                test_label = label.loc[split:]
                timestamp = timestamp.loc[split:]  # Takes the last 1% of timestamps

                print(len(train_data))
                init_act = 0

                from sklearn.preprocessing import StandardScaler
                scaler = StandardScaler()

                scaler.fit(train_data)
                # Environment
                count_iter = 0
                env = Env(args, train_data, train_label, init_act, scaler, count_iter)  # this is for regular Env
                # env = Env(train_data, train_label, init_act) #this is for env_rainbow
                Env.timestamp = Traintimestamp
                env.train()  # sets env.training to True
                action_space = env.action_space()  # pulls action space value -see env.py

                # Agent
                dqn = Agent(args, env)
                mem = ReplayMemory(args, args.memory_capacity)
                priority_weight_increase = (1 - args.priority_weight) / (args.T_max - args.learn_start)

                # Construct validation memory
                val_mem = ReplayMemory(args, args.evaluation_size)
                T, done = 0, True
                while T < args.evaluation_size:
                    if done:
                        state, placeholder, placeholder2,placeholder3 = env.reset()
                        done = False

                    next_state, _, done = env.step(random.randint(0, action_space - 1))
                    val_mem.append(state, None, None, done)
                    state = next_state
                    T += 1

                if args.evaluate == True:

                    dqn.eval()  # Set DQN (online network) to evaluation mode
                    avg_reward, avg_Q, action, actualLabel, TimestampAtthatValue, action_list, rcm_compare,feature_data = test(args,
                                                                                                                  0,
                                                                                                                  dqn,
                                                                                                                  val_mem,
                                                                                                                  test_data,
                                                                                                                  test_label,
                                                                                                                  timestamp,
                                                                                                                  init_act,
                                                                                                                  scaler,
                                                                                                                  evaluate=True)  # Test

                    # timestampAtNow = datetime.ti  #fromtimestamp(TimestampAtthatValue / 1000.0)
                    print("feature data points " , feature_data, "  Timestamp ", TimestampAtthatValue)
                    print("Predicted Action", action, "Actual Label", actualLabel, "TimestampwhilePred",
                          TimestampAtthatValue, datetime.utcfromtimestamp(TimestampAtthatValue[0] / 1000))
                    print('Avg. reward: ' + str(avg_reward) + ' | Avg. Q: ' + str(avg_Q))
                    # print(test_data) #prints the small amount of test  used in the above test function - see ln 139

                    # Main_Perfect_Trade.fetch_and_format_data()          #Writes data to disk
                    resample.read_format_write()  # Pulls data from p file, formats it for use into pkl file
                    data_dict = Main_Perfect_Trade.load_pickle_data()  # Reloads .p file as .pkl which casts as a dataframe

                    # Create Buy/sell here based on data generated by dqn.act() function
                    millis = int(round(time.time() * 1000))

                    print("--------------------------------------------------------------------")

                    print("Predicted Value:", action)
                    print("USD:", amount_USD)#amount_owned_USD)
                    print("BTC:", amount_BTC)#amount_owned_BTC)


                    if (action == 1 or action == 2):
                        if (firstround):
                            action_comparision['previousAction'] = action
                            firstround = False
                        else:
                            action_comparision['presentAction'] = action
                            print('Present Action - ', action_comparision['previousAction'], 'Previous Action  -',
                                  action_comparision['presentAction'])
                            now = time.time()
                            diffrence = now - start
                            print("Time Difference since transaction", diffrence)

                            if (action_comparision['presentAction'] != action_comparision['previousAction']):
                                print(" Do transanction")
                                if ((action == 1 and actualLabel == 1) and amount_USD > 0):
                                    # and (millis - timestamp.iloc[-1]) <= 60000:
                                    print("Buy")
                                    # Log the purchase price
                                    symbol = 'BTC/USDT'  # TODO: If this is changed, the coin below must also be changed
                                    buy_price = avg_price.iloc[-1]

                                    amount_buy = amount_USD / buy_price
                                    # Create Buy order at a valley
                                    #buy = exchange.create_market_buy_order(symbol, amount_buy)
                                    #buyorderstatus.append(buy)
                                    buyorderstatus.append("Buy")

                                    amount_BTC += amount_buy

                                    buy_sell_data = pd.DataFrame(buyorderstatus)
                                    #buy_sell_data.to_csv("buy_sell_data.csv")
                                    transanctionHappend = True
                                    start = time.time()


                                elif ((
                                              action == 2 and actualLabel == 2) and amount_BTC >= .0001):  # and (millis - timestamp.iloc[-1]) <= 60000:
                                    print("Sell")
                                    # Log the sell price
                                    symbol = 'BTC/USDT'  # TODO: If this is changed, the coin below must also be changed

                                    sell_price = avg_price.iloc[-1]
                                    #sell = exchange.create_market_sell_order(symbol, amount_owned_BTC)
                                    #buyorderstatus.append(sell)
                                    buyorderstatus.append("Sell")

                                    buy_sell_data = pd.DataFrame(buyorderstatus)
                                    #buy_sell_data.to_csv("buy_sell_data.csv")
                                    # Create sell order at a peak
                                    profit_USD.append(sell_price - buy_price)  # Create an array of profit
                                    amount_USD = amount_BTC * sell_price

                                    # Unpolished definitions for % profit
                                    average_profit = sum(profit_USD) / len(profit_USD)
                                    print(
                                        'Percent Profit:' + str(average_profit) + '|USD Profit' + str(sum(profit_USD)))
                                    transanctionHappend = True
                                    start = time.time()


                                elif (action == 1 and amount_USD <= 0):
                                    print("Attempted Buy - USD not enough.")
                                elif (action == 2 and amount_BTC < .0001):
                                    print("Attempted Buy - BTC not enough.")
                                elif action == 1:
                                    print("Attempted Buy - But actual label not matched.")
                                elif action == 2:
                                    print("Attempted Sell - But actual label not matched.")
                                start = time.time()
                                action_comparision['previousAction'] = action

                            elif (diffrence > 3600):
                                print(" Do transanction as timeout")
                                if ((action == 1 and actualLabel == 1) and amount_USD > 0):
                                    # and (millis - timestamp.iloc[-1]) <= 60000:
                                    print("Buy")
                                    # Log the purchase price
                                    symbol = 'BTC/USDT'  # TODO: If this is changed, the coin below must also be changed
                                    buy_price = avg_price.iloc[-1]

                                    amount_buy = amount_USD / buy_price
                                    # Create Buy order at a valley
                                    #buy = exchange.create_market_buy_order(symbol, amount_buy)
                                    #buyorderstatus.append(buy)
                                    buyorderstatus.append("Buy")

                                    amount_BTC += amount_buy

                                    buy_sell_data = pd.DataFrame(buyorderstatus)
                                    #buy_sell_data.to_csv("buy_sell_data.csv")
                                    transanctionHappend = True
                                    start = time.time()

                                elif ((
                                              action == 2 and actualLabel == 2) and amount_BTC >= .0001):  # and (millis - timestamp.iloc[-1]) <= 60000:
                                    print("Sell")
                                    # Log the sell price
                                    symbol = 'BTC/USDT'  # TODO: If this is changed, the coin below must also be changed

                                    sell_price = avg_price.iloc[-1]
                                    #sell = exchange.create_market_sell_order(symbol, amount_owned_BTC)
                                    #buyorderstatus.append(sell)
                                    buyorderstatus.append("Sell")


                                    buy_sell_data = pd.DataFrame(buyorderstatus)
                                    #buy_sell_data.to_csv("buy_sell_data.csv")
                                    # Create sell order at a peak
                                    profit_USD.append(sell_price - buy_price)  # Create an array of profit
                                    amount_USD = amount_BTC * sell_price
                                    # Unpolished definitions for % profit
                                    average_profit = sum(profit_USD) / len(profit_USD)
                                    print(
                                        'Percent Profit:' + str(average_profit) + '|USD Profit' + str(sum(profit_USD)))
                                    transanctionHappend = True
                                    start = time.time()


                                elif (action == 1 and amount_USD <= 0):
                                    print("Attempted Buy - USD not enough.")
                                elif (action == 2 and amount_BTC < .0001):
                                    print("Attempted Buy - BTC not enough.")
                                elif action == 1:
                                    print("Attempted Buy - But actual label not matched.")
                                elif action == 2:
                                    print("Attempted Sell - But actual label not matched.")
                                start = time.time()
                                action_comparision['previousAction'] = action
                                start = time.time()


                    elif action == 0:
                        print("No action - The market has not moved enough!")

                    print("--------------------------------------------------------------------")
                    # print ("done. exiting...")
                    # exit(0)

                else:
                    # Training loop
                    dqn.train()
                    T, done = 0, True

                    while T < args.T_max:

                        if done:
                            state, labelplaceholder2, timestampplaceholder2 , dat_placeholder2= env.reset()
                            done = False

                        if T % args.replay_frequency == 0:
                            dqn.reset_noise()  # Draw a new set of noisy weights

                        action = dqn.act(state)  # Choose an action greedily (with noisy weights)

                        next_state, reward, done = env.step(action)  # Step
                        if args.reward_clip > 0:
                            reward = max(min(reward, args.reward_clip), -args.reward_clip)  # Clip rewards
                        mem.append(state, action, reward, done)  # Append transition to memory
                        T += 1

                        if T % args.log_interval == 0:
                            Main_Perfect_Trade.log('T = ' + str(T) + ' / ' + str(args.T_max))

                        # Train and test
                        if T >= args.learn_start:
                            mem.priority_weight = min(mem.priority_weight + priority_weight_increase,
                                                      1)  # Anneal importance sampling weight β to 1

                            if T % args.replay_frequency == 0:
                                dqn.learn(mem)  # Train with n-step distributional double-Q learning

                            if T % args.evaluation_interval == 0:
                                dqn.eval()  # Set DQN (online network) to evaluation mode
                                avg_reward, avg_Q, _, _, _, action_list, rcm_compare,data_placeholder = test(args, 0, dqn, val_mem,
                                                                                            test_data, test_label,
                                                                                            timestamp, init_act, scaler,
                                                                                            evaluate=True)  # Test
                                print("Training Loop ", data_placeholder)

                                # avg_reward, avg_Q = test(args, T, dqn, val_mem)  # Test
                                Main_Perfect_Trade.log(
                                    'T = ' + str(T) + ' / ' + str(args.T_max) + ' | Avg. reward: ' + str(
                                        avg_reward) + ' | Avg. Q: ' + str(avg_Q))
                                dqn.train()  # Set DQN (online network) back to training mode
                                # Change 7 (profit/loss calc, confusion matrix, pickle writing


                                cal_money, cal_units, pred_data = singleTradeCommand(test_prices, action_list,
                                                                          pred_money,
                                                                          pred_units, cal_fee, timestamp)


                                cm = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
                                for ln in pred_data:
                                    action = int(ln[1])
                                    target = int(ln[2])
                                    cm[target][action] += 1
                                print(len(pred_data))
                                print("RCM_CHECK: {}".format(rcm_compare))
                                print("P/L CM: {}".format(cm))

                                if np.all(cm == rcm_compare):
                                    print("Matching Confusion Matrix: True")

                                else:
                                    print("Matching Confusion Matrix?\n {}".format(cm == rcm_compare))
                                    continue
                                index = 3

                                firstPrice = pred_data[0][index]

                                print("-----")
                                #print ("Action-List:", action_list)
                                print ("Target-List", target)
                                print("First price: $", firstPrice)
                                final_price = pred_data[len(pred_data) - 1][index]
                                print ("Final price $", final_price)

                                print()
                                print("delete ({}):  \ncu = {},  cm = {}".format(T, cal_units, cal_money))
                                print ("\t ^^ is worth ${}".format(cal_units*final_price + cal_money))

                                print("-----")

                                with open('btc_pred_cm.p', 'wb') as handle:
                                    pickle.dump(cm, handle, protocol=pickle.HIGHEST_PROTOCOL)

                                save_path_pred = os.path.join(script_path, 'btc_labeled_pred.p')
                                with open(save_path_pred, mode='wb') as handler:
                                    pred_data = pd.DataFrame(pred_data,
                                                             columns=["Timestamp", "Action", "Target", "Average Price",
                                                                     "Open Price", "Close Price"])


                                    pickle.dump(pred_data, handler, protocol=pickle.HIGHEST_PROTOCOL)


                                for ln in pred_data:
                                #
                                    # print ("ln = {}, ln[index] = {}".format( ln, ln[index]))
                                    price = ln[index]    #TO REVERT to earlier version, ind -> index
                                #
                                # # to Matt: price is single letter. Im trying to figure out why. What are you trying to accomplish?
                                # print ("---------------------")
                                # unitCost = float(cal_units)*float(price)
                                # print ("-- cal_units = {} ({}), price = {} ({})".format(cal_units, type(cal_units), price, type(price)))
                                # print("Current Unit Price: {} units = ${}".format(cal_units, unitCost))
                                # print("Ending Price (Close): ${}".format(price))
                                # print("Profit/Loss: ${}".format((unitCost + cal_money) - firstPrice))
                                #
                                with open('btc_labeled_pred.p', 'wb') as handle:
                                #
                                    pickle.dump(pred_data, handle, protocol=pickle.HIGHEST_PROTOCOL)
                                for lst in cm:
                                    print(lst)
                                #
                                # # print("finish")
                                # # quit()
                                print("Ending Asset Amounts: $ {} Units {}".format(cal_money, cal_units))



                            # Update target network
                            if T % args.target_update == 0:
                                dqn.update_target_net()

                        state = next_state
                        p += 1

                        dqn.save()
                now1 = datetime.now()
                print("Loop end time = ", now1.strftime("%H:%M:%S"))
                print ("exiting... (training)")
                #exit(0)
            except Exception as e:
                print("Error:", e)
                logging.basicConfig(filename='ErrorLog.log', format='%(asctime)s %(message)s', level=logging.ERROR)
                logging.debug(logging.exception("~~~~~~~~~~~~~~~~~~~~~~~~"))
                raise

            Main_Perfect_Trade.fetch_and_format_data()  # Writes data to disk
            resample.read_format_write()  # Pulls data from p file, formats it for use into pkl file
            data_dict = Main_Perfect_Trade.load_pickle_data()  # Reloads .p file as .pkl which casts as a dataframe

    #            args.T_max += len(data_dict['label'])
    #            if args.T_max % args.log_interval != 0:
    #                 args.T_max = args.T_max - (args.T_max % args.log_interval)
    # Main_Perfect_Trade.train_and_predict(data_dict)     #Reload training func
    # Create new func that pulls data, writes to disk, reads to disk from resample, increases T-max
    # and then loops through train_and_predict func
    # (int(round(time.time() * 1000))) - 65000000000
    #  1564372800000

    # Safe First BTC/USDT date (meaning absolutely no repeating data points): '2018-5-29 01:00:00'

    def fetch_and_format_data(symbol='BTC/USDT',
                              from_datetime= 1527570000000,
                              timeframe='1m', first_loop = 'True',
                              exchange=ccxt.binance({'rateLimit': 5000,
                                                     'enableRateLimit': True,
                                                     'recvWindow': 1000000000000,
                                                     'nonce': ccxt.Exchange.milliseconds,
                                                     'options': {'adjustForTimeDifference': True}})):
        '''
         576300000 should account for the last 10000 data sets, allowing for propper training, and predictions
                                  from_datetime='2018-01-01 00:00:00',
        Params -Symbol - symbol of coin
                from datetime - date based timestamp, y-mon-day hr:min:sec
                timeframe - amount of data
                exchange - exchange chosen
        Purpose - Pulls data and writes it to df, then labels it, then passes it to pickle file, this will be used
                  in the above loop for continuous updating of values.
        Returns - Nothing, it writes a pickle value to disk
        NOTE: Any duplicate functions from AI_Crypto_GUI will be labeled and placed in the
        resample.py file.
            - They are reused due to undetermined errors within the master branch - AI_Crypto_GUI
        '''

        btc_df_latest = resample.fetch_OHLCV_data(exchange=exchange,
                                                  symbol=symbol,
                                                  timeframe=timeframe,
                                                  from_datetime= 1502946000000)  # Fetches OHLCV data from_datetime
        #startdate for BTC/USD should be 2017-08-17 (1502946000000)
        # From AI_Crypto_GUI.py    #09/14/2017 date
        btc_withLabel, _ = resample.label_perfect_trades(btc_df_latest, 0, True)  # Labels data

        pickle.dump(btc_withLabel, open('btc_labeled.p', 'wb'))  # dumps df btc_withLabel to pickle file
        resample.read_format_write()

    def fetch_balanace(coin="BTC"):

        exchange = ccxt.binance({'ratelimit': 60000, 'enableRateLimit': True,
                                 'api_key': '',
                                 'secret': '',
                                 'options': {'adjustForTimeDifference': True}})
        values = exchange.fetch_balance()  # Gets all coins carried by the exchange

        for value in values:  # For every coin within values
            if coin in values.keys():  # For every coin contained wthin the keys
                coin_value = values.get(coin)  # Fetches coin based on the input in the function
                if coin_value.get(
                        'free') != None:  # and coin_value.get('free') > .001: # Checks that there is a value free associated with the coin
                    print(coin, ":", coin_value.get('free'))
                    return coin_value.get('free')  # Returns the amount of free coin based on the coin input
                else:
                    print("You do not own this coin.")


# Main_Perfect_Trade.fetch_balanace()
Main_Perfect_Trade.fetch_and_format_data()
Main_Perfect_Trade.train_and_predict(Main_Perfect_Trade.load_pickle_data())
