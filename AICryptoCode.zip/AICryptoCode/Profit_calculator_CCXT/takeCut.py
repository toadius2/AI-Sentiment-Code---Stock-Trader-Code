import datetime

def takeCutPeriodical (profit, cutPercentage, offsetDays = 0, timeScale = 'days', interval = 5):
    cutNum = cutPercentage/100.0
    fileHandle = open('cut_logs_periodical.txt', "r")
    lineList = fileHandle.readlines()
    fileHandle.close()

    now = datetime.datetime.today() + datetime.timedelta(days=offsetDays)

    if lineList == []:
        # Log this is as starting date, but don't take cut
        nowLog = now.replace(hour=0, minute=0, second=0,
                             microsecond=0)  # logs as if it did it first thing in the day, regardless of time
        log(nowLog, profit, 0)
        return profit, 0
    else:
        latestLog = lineList[-1]
        latestLogList = latestLog.split(" ")
        latestCut = float(latestLogList[3])
        dateStr = " ".join(latestLogList[:2])
        latestProfit = float(latestLogList[2])
        latestDate = datetime.datetime.strptime(dateStr, "%Y-%m-%d %H:%M:%S")

        firstLog = lineList[0]
        firstLogList = firstLog.split(" ")
        fdateStr = " ".join(firstLogList[:2])
        firstDate = datetime.datetime.strptime(fdateStr, "%Y-%m-%d %H:%M:%S")

        if timeScale == 'days':
            diff = (now - latestDate).days
            if diff == 0:
                return profit, 0
            if (now-firstDate).days % interval == 0 or diff > interval:
                profitDiff = profit - latestProfit
                cut = profitDiff*cutNum
                nowLog = now.replace(hour=0, minute=0, second=0, microsecond=0)      # logs as if it did it first thing in the day, regardless of time
                if profitDiff <= 0:
                    log (nowLog, profit, latestCut)
                    return profit, 0
                log(nowLog, profit-cut, cut+latestCut)
                return profit-cut, cut
            return profit, 0

        elif timeScale == 'months':
            thisMonth = now.month
            latestDateMonth = latestDate.month
            if thisMonth < latestDateMonth:
                latestDateMonth -= 12
            if thisMonth - latestDateMonth >= interval:
                log(now, profit)
                profitDiff = profit - latestProfit
                if profitDiff <= 0:
                    return profit, 0
                return profitDiff * (1 - cutNum), profitDiff * cutNum
    print ("Error 1001 (takeCut.py)")
    return None

def log(date, profit, cut):
    with open("cut_logs_periodical.txt", "a") as text_file:
        text_file.write(str(date)+" " + str(profit) + " " + str(cut) + "\n")
        text_file.close()
    return