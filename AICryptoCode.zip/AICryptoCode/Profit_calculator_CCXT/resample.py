import os.path as path
from collections import defaultdict

import pandas as pd
import numpy as np
import pickle
import talib
import time
import ccxt
import technicalindicators as ti

script_path = path.dirname(__file__)


def assign_labels(price_chart, trigger_price, fee_percentage, new_training):
    if (new_training == True):
        trigger_price = price_chart['Closing_Price'].iloc[0]
    else:
        trigger_price = trigger_price

    label_df = pd.DataFrame(columns=['target'])
    label_df['target'] = np.zeros(len(price_chart['Closing_Price'].values))

    for i in range(len(price_chart['Closing_Price'].values) - 1):
        if price_chart['Closing_Price'].iloc[i + 1] > trigger_price + (trigger_price * fee_percentage):
            label_df['target'].at[i] = 1
            trigger_price = price_chart['Closing_Price'].iloc[i]

        elif price_chart['Closing_Price'].iloc[i + 1] < trigger_price - (trigger_price * fee_percentage):
            label_df['target'].iloc[i] = 2
            trigger_price = price_chart['Closing_Price'].iloc[i]

        else:
            label_df['target'].at[i] = 0

        price_chart = pd.concat([price_chart, label_df], 1)

    return price_chart, trigger_price


def OHLCV(df):
    return df




def feat_extract(df):
    close = df['Closing_Price'].values.astype(np.float)
    vol = df['Volume'].values.astype(np.float)
    df_ = df

    df_ = pd.DataFrame(index=df.index)

    df_['r'] = np.log(talib.ROCR(close, timeperiod=1))
    df_['r_1'] = np.log(talib.ROCR(close, timeperiod=2))
    df_['r_2'] = np.log(talib.ROCR(close, timeperiod=3))

    r = df_['r'].values

    zscore = lambda x, timeperiod: (x - talib.MA(x, timeperiod)) / (talib.STDDEV(x, timeperiod) + 1e-8)
    df_['rZ12'] = zscore(r, 12)
    df_['rZ60'] = zscore(r, 60)

    change = lambda x, timeperiod: x / talib.MA(x, timeperiod) - 1
    df_['pma12'] = zscore(change(close, 12), 60)
    df_['pma60'] = zscore(change(close, 60), 60)
    df_['pma672'] = zscore(change(close, 672), 60)

    ma_r = lambda x, tp1, tp2: talib.MA(x, tp1) / talib.MA(x, tp2) - 1
    df_['ma4/36'] = zscore(ma_r(close, 4, 36), 60)
    df_['ma12/60'] = zscore(ma_r(close, 12, 60), 60)

    def acc(x, tp1, tp2):
        x_over_avg = x / talib.MA(x, tp1)
        value = x_over_avg / talib.MA(x_over_avg, tp2)
        return value

    df_['ac12/12'] = zscore(acc(close, 12, 12), 60)
    df_['ac60/60'] = zscore(acc(close, 60, 12), 60)

    df_['vZ12'] = zscore(vol, 12)
    df_['vZ60'] = zscore(vol, 60)
    df_['vZ672'] = zscore(vol, 672)

    df_['vma12'] = zscore(change(vol, 12), 60)
    df_['vma60'] = zscore(change(vol, 60), 60)
    df_['vma672'] = zscore(change(vol, 672), 60)

    df_['vol12'] = zscore(talib.STDDEV(r, 12), 60)
    df_['vol60'] = zscore(talib.STDDEV(r, 60), 60)
    df_['vol672'] = zscore(talib.STDDEV(r, 672), 60)

    df_['dv12/60'] = zscore(change(talib.STDDEV(r, 12), 60), 60)
    df_['dv60/672'] = zscore(change(talib.STDDEV(r, 60), 672), 60)

    # df_feature = df[['Open_Price', 'Highest_Price', 'Lowest_Price', 'Closing_Price', 'Volume']]
    # changing the formate of the data frame to suit for the functions in tecnicalIndicators
    # df_feature.columns = ['Open', 'High', 'Low', 'Close', 'Volume']
    # df_['sma'] = ti.moving_average(df_feature, 20)
    # df_['atr'] = ti.average_true_range(df_feature, 15)
    # df_['adx'] = ti.average_directional_movement_index(df_feature, 10, 10)
    df_ = df_.fillna(0.)
    assert (not df.isnull().values.any()), 'feature dframe contain NaNs'
    return df_


# if __name__ == '__main__':
def read_format_write():
    # Reads data from a btc_labeled.p file then formats said data

    # load csv
    df_reward = pickle.load(open('eos_labeled.p', 'rb'))[
        'target']  # Pulls from file written in aicryptogui from binance data
    df_feature = pickle.load(open('eos_labeled.p', 'rb')).drop(['target', 'Timestamp_ms'], 1)  # Reads this data, and
    df_full = pickle.load(open('eos_labeled.p', 'rb'))

    # df.index = pd.to_datetime(df.index, unit='s')

    # select period between Dec. 1, 2014 ~ Jun. 14, 2017
    # start_date = pd.Timestamp(year=2014, month=12, day=1, hour=0, minute=0)
    # end_date = pd.Timestamp(year=2017, month=6, day=14, hour=23, minute=59)
    # mask = (df.index >= start_date) & (df.index <= end_date)
    # df = df.loc[mask]
    # df_feature.drop(['Timestamp_ms'],1,inplace=True)
    # drop and change column names
    df_feature = df_feature[['Open_Price', 'Highest_Price', 'Lowest_Price', 'Closing_Price', 'Volume']]
    df_feature.rename(columns={'Volume_(BTC)': 'Volume'}, inplace=True)
    df = OHLCV(df_reward)
    print(df.head())
    # # save the csv file for further use if you want
    # save_path = path.join(script_path, 'BTCUSD-15Min.csv')
    # df.to_csv(save_path)
    # df = pd.read_csv(save_path,
    #                  index_col=[0],
    #                  parse_dates=True)

    feat_df = feat_extract(df_feature)
    print(feat_df.head())  # print(feat_df.head()) #

    data_dict = {
        'data': feat_df,
        'label': df,
        'full_data': df_full
    }

    save_path = path.join(script_path, 'EOSUSD-15Min-Data.pkl')
    with open(save_path, mode='wb') as handler:
        pickle.dump(data_dict, handler, protocol=pickle.HIGHEST_PROTOCOL)


def fetch_OHLCV_data(exchange, symbol, timeframe, from_datetime, fetch_status=True):
    # function to get candle chart for time period
    # returns dataframe

    # PARAMS
    # exchange - ccxt exchange object that determines which exchange to pull OHLCVS from
    # symbol - string that represent symbol from respective exchange
    # timeframe - string for intervals between each price
    # from_datetime - when to begin price /ticker information
    '''
            NOTE: THIS WAS COPIED FROM aicryptogui.py due to undetermined errors within that branch. 
        '''
    msec = 1000
    minute = 60 * msec
    hour = 60 * minute
    hold = 30

    # from_timestamp = exchange.parse8601(from_datetime)
    from_timestamp = from_datetime

    now = exchange.milliseconds()
    flag_first = True
    flag_sec = False
    data = []
    # i = 0
    while from_timestamp < now:
        # while len(data) < 25001:
        # i = i + 1
        print("i = ", len(data))
        try:
            if (fetch_status == True):
                print(exchange.milliseconds(), 'Fetching candles starting from', exchange.iso8601(from_timestamp))
            ohlcvs = exchange.fetch_ohlcv(symbol, timeframe, from_timestamp)
            if (fetch_status == True):
                print(exchange.milliseconds(), 'Fetched', len(ohlcvs), 'candles')
            if (len(ohlcvs) > 1):
                first = ohlcvs[0][0]
                last = ohlcvs[-1][0]


            else:
                first = ohlcvs
                last = ohlcvs

            if (fetch_status == True):
                print('First candle epoch', first, exchange.iso8601(first))
                print('Last candle epoch', last, exchange.iso8601(last))

            # if (len(data) > 20965 and flag_first):# 18001, 26001 # at around 38000, catches up to present
            #    flag_first = False
            #    flag_sec = True
            #     break
            # if (len(data) > 20985 and flag_sec):
            #    flag_first = True
            #    flag_sec = False
            #    break

            # either remove or include additoinal params like day or month , whatever ccxt allows
            from_timestamp += len(ohlcvs) * minute
            data += ohlcvs

        except:

            print('Got an error. Retrying in', hold, 'seconds...')
            time.sleep(hold)
    data = pd.DataFrame(data, columns=['Timestamp_ms', 'Open_Price', 'Highest_Price', 'Lowest_Price', 'Closing_Price',
                                       'Volume'])
    data = data.dropna()
    #        if len(data) > 1000:
    #            amount_to_drop = len(data) % 1000
    #            data.drop(amount_to_drop)
    #

    return data


def label_perfect_trades(priceHistory, triggerPrice, new_training=False):
    # labels perfect trades as peaks , valleys or neutral
    # params
    # priceHistory - dataframe of OHLCVS
    label_df = pd.DataFrame(columns=['target'])
    label = []
    dict1 = {}
    dict2 = {}
    dict_count = defaultdict(int)
    data = priceHistory['Closing_Price'].values
    trigger = data[0]
    for i in range(0, len(data)):
        # print("Iteration", i)
        # print("count", dict_count[2], dict_count[1])
        if data[i] > 1.001 * trigger:
            if dict_count[1] >= 2:
                dict_count[1] = 1
                dict2 = {}

            trigger = data[i]
            label.append(2)

            if 2 in dict2:
                label[dict2[2]] = 0
                dict2[2] = i

            else:
                dict2[2] = i

            if 2 not in dict_count:
                dict_count[2] = 1
            else:
                dict_count[2] += 1



        elif data[i] < 0.999 * trigger:
            if dict_count[2] >= 2:
                dict_count[2] = 1
                dict1 = {}

            trigger = data[i]
            label.append(1)

            if 1 in dict1:
                label[dict1[1]] = 0
                dict1[1] = i
            else:
                dict1[1] = i

            if 1 not in dict_count:
                dict_count[1] = 1
            else:
                dict_count[1] += 1
        else:
            # trigger = data[i]
            label.append(0)

    label_datafram = pd.DataFrame(label, columns=['target'])

    priceHistory = pd.concat([priceHistory, label_datafram], 1)
    # label_df['Closing_Price'] = priceHistory['Closing_Price'].values
    # if (new_training==True):
    #     triggerPrice = label_df['Closing_Price'].at[0]
    # else:
    #     triggerPrice = triggerPrice
    # for i in range(len(label_df['Closing_Price'].values) - 1):
    #     if label_df['Closing_Price'].at[i + 1] > triggerPrice + (triggerPrice * 0.001):
    #         label_df['target'].at[i + 1] = 2
    #         triggerPrice = label_df['Closing_Price'].at[i + 1]
    #     elif label_df['Closing_Price'].at[i + 1] < triggerPrice - (triggerPrice * 0.001):
    #         label_df['target'].at[i + 1] = 1
    #
    #         triggerPrice = label_df['Closing_Price'].at[i + 1]
    #     else:
    #         label_df['target'].at[i + 1] = 0
    #
    # priceHistory = pd.concat([priceHistory, label_df.drop('Closing_Price', 1)], 1)
    #        if (len(priceHistory) > 2):
    #            priceHistory.fillna(0).to_csv('formatted_data.csv')
    return priceHistory.fillna(0), triggerPrice
