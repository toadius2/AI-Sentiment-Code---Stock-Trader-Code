from collections import deque
import random
import torch

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import os.path
import pickle
import math
from torch.autograd import Variable
import torch
import talib

ct = 1

class Env():
  def __init__(self, args, train_df, train_label, init_act, s, count_iter):

    actions = [0,1,2]
    self.actions = dict([i, e] for i, e in zip(range(len(actions)), actions))

    self.state_buffer = deque([], maxlen=args.history_length)
    self.training = True  # Consistent with model training mode
    self.c = count_iter
    self.init_act = init_act
    self.i_step = 0
    self.i_act = init_act
    self.OHLCV = None
    reward = None
    # self.timestamp = timestamp
    self.timestampAtThatPoint = None
    scaler = s
    #train_df = pd.DataFrame(scaler.transform(train_df.values), columns=train_df.columns)
    train_df = pd.DataFrame(scaler.transform(train_df.values), columns=train_df.columns)

    self.train_df = torch.from_numpy(np.expand_dims(train_df.values, axis=1).astype(np.float32))
    self.train_label = train_label.values
    self.iter = None
    self.label_counts = {}
    for i in self.train_label:
      # get(key, default) falls back to default if key is not present

      self.label_counts[i] = self.label_counts.get(i, 0) + 1

    self.guess_counts = [0,0,0]

    self.wrong_multiplier = 0.0
  timestamp = None
  def _get_state(self):
    return Variable(torch.tensor([self.OHLCV]))

  def _reset_buffer(self):
    for _ in range(self.window):
      self.state_buffer.append(torch.zeros(84, 84))

  def reset(self):
    self.i_step = 0
    self.i_act = self.init_act
    self.OHLCV = None
    reward = None
    # if(Env.timestamp == None):
    #   self.iter = zip(iter(self.train_df), iter(self.train_label))
    #   s0, self.OHLCV = next(self.iter)
    #   timestampAtThatPoint = None
    # else:

    self.iter = zip(iter(self.train_df), iter(self.train_label))

    s0, self.OHLCV = next(self.iter)
    # self.iter = zip(iter(self.train_label), iter(Env.timestamp))
    # self.OHLCV, timestampAtThatPoint = next(self.iter)
    self.iter2 = zip(iter(Env.timestamp))
    # self.timestampAtThatPoint = Env.timestamp.tolist()[self.c]#next(self.iter2)   #eric
    observation = s0
    # self.iter = zip(iter(self.train_df), iter(self.train_label), iter(Env.timestamp))
    # s0, self.OHLCV, timestampAtThatPoint = next(self.iter)
    #
    #
    # observation = s0
    self.state_buffer.append(observation)
    return torch.stack(list(self.state_buffer), 0), self.OHLCV, self.timestampAtThatPoint, observation  #eric (self.)

  def step(self, action):

    # Repeat action 4 times, max pool over last 2 frames
    if self.c < len(self.train_label)-1:
      self.c+=1
      s_, self.OHLCV = next(self.iter)
      target = int(self.OHLCV)
      state = s_

      self.timestampAtThatPoint = Env.timestamp.tolist()[self.c]  # next(self.iter2)   #eric

      # print ("[c = {}]\t target = {}, state = {} ({})".format(self.c, target, state, type (state)))
      # print ("\t\t {}".format(self.label_counts))
      if self.c < 3:
        print ("delete", self.c)
        print ("\t b. {} -- {}".format(type(self.timestamp), len(self.timestamp)))
        from random import randrange
        r = randrange(10)
        print ("\t d. {} (rn = {}), sum = {} (type = {})(len = {})".format(self.train_label[self.c-1], self.c-1, self.train_label.sum(), type(self.train_label[0]), len(self.train_label)))
        print ("\t e. (LEN = {}, state = {} \n \t\t (type = {})".format(len(state.tolist()[0]), state.tolist()[0], self.state_buffer[0]))
        print ("\t f. timestamp = {} (type = {})".format(len(self.timestamp), type(self.timestamp)))
        print ("\t g. timestampAtThatPoint = {}".format(self.timestampAtThatPoint))
        print("\t h. Data at that point = {}  (ind = {})".format(self.timestampAtThatPoint, self.c))



      #Ensures that the values above 
      #if self.label_counts[0] != 0:    
      try:
          zero_r =  1/self.label_counts[0]
      #else:
      except:
          zero_r = 0
       
      #if self.label_counts[1] != 0:
      try:
          one_r = 1/self.label_counts[1]
      except:
      #else:
          one_r = 0
          
      #if self.label_counts[2] != 0:
      try: 
          two_r = 1/self.label_counts[2]
      #else:
      except: 
          two_r = 0
      #Dont print this unless you want to see a LOT of values
      #print("Action value:", action, "Target:", target)


        #Checks if the target and action values are the same and gives reward
      if target == 0 and action == 0:
        reward = 1000 #(zero_r/4)
        self.wrong_multiplier=0.0
      elif target == 1 and action == 1:
        reward = 1000#one_r
        self.wrong_multiplier=0.0

      elif target == 2 and action == 2:
        reward = 1000#two_r
        self.wrong_multiplier=0.0

      elif target == 1 and action != 1:
        self.wrong_multiplier=1
        reward = -2000#-1* (zero_r+two_r)/2 * self.wrong_multiplier
      elif target == 2 and action != 2:
        self.wrong_multiplier=1
        reward = -2000#-1* (zero_r+one_r)/2 * self.wrong_multiplier
      elif target == 0 and action != 0:
        self.wrong_multiplier=1
        reward = -2000#-1 *(one_r+two_r)/2 * self.wrong_multiplier
      else:
        self.wrong_multiplier+=0.1
        reward = -2  * self.wrong_multiplier
      done = False
      observation = state
      self.state_buffer.append(observation)
      self.init_act = action

      self.guess_counts[action]+=1

      

    else:
      done = True
      reward = 0


    # Detect loss of life as terminal in training mode
    # Return state, reward, done

    return torch.stack(list(self.state_buffer), 0), reward, done

  # Uses loss of life as terminal signal
  def train(self):
    self.training = True

  # Uses standard terminal signal
  def eval(self):
    self.training = False

  def action_space(self):
    return len(self.actions)
