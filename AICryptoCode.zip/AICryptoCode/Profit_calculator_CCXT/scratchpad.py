# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
# import requests
# import datetime
# import pickle
# from nltk.tokenize import sent_tokenize
# from nltk.sentiment.vader import SentimentIntensityAnalyzer
# from collections import defaultdict
# from newspaper import Article
# from bs4 import BeautifulSoup
#
# index = ['BTC', 'ETH', 'LTC', 'BCH']
# coin_names = {'bitcoin': 'BTC',
#                                'ethereum': 'ETH',
#                                'litecoin': 'LTC',
#                                'bitcoin cash': 'BCH'}
# for i in index:
#     coin_names[i.lower()] = i
#
# print(coin_names)
#
# sentiment = pd.DataFrame(np.empty((len(index), 6), dtype=object), index=index,
#                                           columns=['Last_News_Updated_Time', 'Current_sentiment', 'Last_sentiment',
#                                                    'Current_Overall_Market_sentiment', 'Last_Overall_Market_sentiment',
#                                                    'Market_Price'])
#
# print(sentiment.index == 'BTC' )
#
# for idx in sentiment.index:
#     if(idx == 'BTC'):
#         current_senti = sentiment.loc[idx]['Current_sentiment']
#         print(current_senti)
#
# sid = SentimentIntensityAnalyzer()
#
# sentences = ["VADER is smart, handsome, and funny.", # positive sentence example
#     "VADER is smart, handsome, and funny!", # punctuation emphasis handled correctly (sentiment intensity adjusted)
#     "VADER is very smart, handsome, and funny.",  # booster words handled correctly (sentiment intensity adjusted)
#     "VADER is VERY SMART, handsome, and FUNNY.",  # emphasis for ALLCAPS handled
#     "VADER is VERY SMART, handsome, and FUNNY!!!",# combination of signals - VADER appropriately adjusts intensity
#     "VADER is VERY SMART, really handsome, and INCREDIBLY FUNNY!!!",# booster words & punctuation make this close to ceiling for score
#     "The book was good.",         # positive sentence
#     "The book was kind of good.", # qualified positive sentence is handled correctly (intensity adjusted)
#     "The plot was good, but the characters are uncompelling and the dialog is not great.", # mixed negation sentence
#     "A really bad, horrible book.",       # negative sentence with booster words
#     "At least it isn't a horrible book.", # negated negative sentence with contraction
#     ":) and :D",     # emoticons handled
#     "",              # an empty string is correctly handled
#     "Today sux",     #  negative slang handled
#     "Today sux!",    #  negative slang with punctuation emphasis handled
#     "Today SUX!",    #  negative slang with capitalization emphasis
#     "Today kinda sux! But I'll get by, lol" # mixed sentiment example with slang and constrastive conjunction "but"
#  ]
# for sentence in sentences:
#      print(sentence)
#      ss = sid.polarity_scores(sentence)
#      for k in sorted(ss):
#         print('{0}: {1}, '.format(k, ss[k]), end='')
#
#
import pandas as pd
import pickle
file_name = "EOSUSD-15Min-Data.pkl"
pickle_in = open(file_name,"rb")
data_dict = pd.read_pickle(file_name)
pd.set_option('display.max_rows', 300)
pd.set_option('display.max_columns', 300)
print(data_dict)

data = data_dict['data']#.to_csv("features_extracted.csv")
print("dat_shape",data.shape)
full_data = data_dict['full_data']
timestamp = full_data['Timestamp_ms']
data_dict['full_data'].to_csv("ohlcv_data.csv")
# data_dict['label'].to_csv("label_data.csv")
# unpickled.to_csv("Raw_data_&_extracted_features.csv")
print()
print("ok")
#print(unpickled.head(40))
print("dat_shape",timestamp.shape)
# example = pickle.load(pickle_in)
# print(example)

data_partial = data.iloc[:,0:22]
data_partial["Time_stamp"] = timestamp
print("dat_shape",data_partial.shape)
print("data_partial = {}".format(data_partial))#, data_partial["Time_stamp"]))