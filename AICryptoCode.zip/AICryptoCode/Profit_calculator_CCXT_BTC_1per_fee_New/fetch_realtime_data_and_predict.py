import math
import pickle
from datetime import datetime
import ccxt
import numpy
import pandas as pd
import torch
import torch.nn as nn
from resample import fetch_OHLCV_data, label_perfect_trades, feat_extract
from torch.nn import functional as F
from sklearn.preprocessing import StandardScaler

#currect time stamp
current_timestamp=int((datetime.now().timestamp())*1000)

#get data for current time stamp
realtime_data = fetch_OHLCV_data(symbol='BTC/USDT',
                              from_datetime= current_timestamp,
                              timeframe='1m',
                              exchange=ccxt.binance({'rateLimit': 5000,
                                                     'enableRateLimit': True,
                                                     'recvWindow': 1000000000000,
                                                     'nonce': ccxt.Exchange.milliseconds,
                                                     'options': {'adjustForTimeDifference': True}}))

#get labels for data recieved
labeled_training_data, triggerprice = label_perfect_trades(realtime_data, 0.000, 'EUR/USD')

#extract features (need BTCUSD-15MIN-Data.pkl file to be present and make sure it is not zero)
featured_training_data_df = feat_extract(labeled_training_data)



scaler = StandardScaler()

transformed_data = scaler.fit_transform(featured_training_data_df)

#get the last row i.e. the data with latest time stamp
array_length = len(transformed_data)
realtime_latest = transformed_data[array_length - 1]

#should be of shape 1X115
print(realtime_latest.shape)


#Model class
class NoisyLinear(nn.Module):
  def __init__(self, in_features, out_features, std_init=0.4):
    super(NoisyLinear, self).__init__()
    self.in_features = in_features
    self.out_features = out_features
    self.std_init = std_init
    self.weight_mu = nn.Parameter(torch.empty(out_features, in_features))
    self.weight_sigma = nn.Parameter(torch.empty(out_features, in_features))
    self.register_buffer('weight_epsilon', torch.empty(out_features, in_features))
    self.bias_mu = nn.Parameter(torch.empty(out_features))
    self.bias_sigma = nn.Parameter(torch.empty(out_features))
    self.register_buffer('bias_epsilon', torch.empty(out_features))
    self.reset_parameters()
    self.reset_noise()

  def reset_parameters(self):
    mu_range = 1 / math.sqrt(self.in_features)
    self.weight_mu.data.uniform_(-mu_range, mu_range)
    self.weight_sigma.data.fill_(self.std_init / math.sqrt(self.in_features))
    self.bias_mu.data.uniform_(-mu_range, mu_range)
    self.bias_sigma.data.fill_(self.std_init / math.sqrt(self.out_features))

  def _scale_noise(self, size):
    x = torch.randn(size)
    return x.sign().mul_(x.abs().sqrt_())

  def reset_noise(self):
    epsilon_in = self._scale_noise(self.in_features)
    epsilon_out = self._scale_noise(self.out_features)
    self.weight_epsilon.copy_(epsilon_out.ger(epsilon_in))
    self.bias_epsilon.copy_(epsilon_out)

  def forward(self, input):
    if self.training:
      return F.linear(input, self.weight_mu + self.weight_sigma * self.weight_epsilon, self.bias_mu + self.bias_sigma * self.bias_epsilon)
    else:
      return F.linear(input, self.weight_mu, self.bias_mu)

class DQN(nn.Module):
  def __init__(self):

    super().__init__()
    self.atoms = 115
    actions = [0, 1, 2]
    self.actions = dict([i, e] for i, e in zip(range(len(actions)), actions))
    self.action_space = len(self.actions)

    self.conv1 = nn.Conv1d(115, 115, 1)
    self.conv2 = nn.Conv1d(115, 115, 1)
    # self.conv3 = nn.Conv1d(64, 64, 1)
    self.lin = nn.Linear(115,115)
    self.fc_h_v = NoisyLinear(115, 115, std_init=0.1)
    self.fc_h_a = NoisyLinear(115, 115, std_init=0.1)
    self.fc_z_v = NoisyLinear(115, 115, std_init=0.1)
    self.fc_z_a = NoisyLinear(115, self.action_space * self.atoms, std_init=0.1)


  def forward(self, x, log=False):
    x = x.view(-1, 115, 1)
    #x = x.cuda()    # this is required for using CUDA/GPU as oposed to CPU, comment out otherwise
    #TODO: Find the parent class that calls this method - pass argument for cpu/gpu to enable/disable ln 64
    x = F.relu(self.conv1(x))

    x = F.relu(self.conv2(x))
   # x = F.relu(self.conv3(x))
    x = x.view(-1, 115)

    x = F.relu(self.lin(x))

    v = self.fc_z_v(F.relu(self.fc_h_v(x)))  # Value stream
    a = self.fc_z_a(F.relu(self.fc_h_a(x)))  # Advantage stream
    v, a = v.view(-1, 1, self.atoms), a.view(-1, self.action_space, self.atoms)
    q = v + a - a.mean(1, keepdim=True)  # Combine streams
    if log:  # Use log softmax for numerical stability
      q = F.log_softmax(q, dim=2)  # Log probabilities with action over second dimension
    else:
      q = F.softmax(q, dim=2)  # Probabilities with action over second dimension
    return q


# predict action
def act(torch_model, state):
  support = torch.linspace(-10, 10,115).to(device=torch.device('cpu'))
  with torch.no_grad():
    return (torch_model(state) * support).sum(2).argmax(1).item()


#define model and load the .pth file to the model
model = DQN()
model.load_state_dict(torch.load('btcmodel.pth'))

#evaluate the model
model.eval()

#create a tensor from numpy array
labels_batch = torch.from_numpy(realtime_latest).float()

#pass the real time data through the model to get output
output=model(labels_batch)

#predict what action should be taken
pred = act(model, labels_batch)

print(pred)
