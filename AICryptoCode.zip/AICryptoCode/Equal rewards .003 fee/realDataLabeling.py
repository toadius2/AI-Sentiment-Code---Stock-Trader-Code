import pickle
import time
from collections import defaultdict

import ccxt
import pandas as pd
action_comparision = defaultdict(int)

# print(variable)
# from datetime import datetime
#
# y = datetime.fromtimestamp(1555462800000/1000) #utcfromtimestamp(1555462800000/1000)
# x = datetime.timestamp(y)
# print(y)
# print(x)
def fetch_OHLCV_data(exchange, symbol, timeframe, from_datetime, fetch_status=True):

    msec = 1000
    minute = 60 * msec
    hour = 60 * minute
    hold = 30

    # from_timestamp = exchange.parse8601(from_datetime)
    from_timestamp = from_datetime

    now = exchange.milliseconds()

    data = []

    while from_timestamp < now:
        # while len(data) < 1001:
        try:
            if (fetch_status == True):
                print(exchange.milliseconds(), 'Fetching candles starting from', exchange.iso8601(from_timestamp))
            ohlcvs = exchange.fetch_ohlcv(symbol, timeframe, from_timestamp)
            if (fetch_status == True):
                print(exchange.milliseconds(), 'Fetched', len(ohlcvs), 'candles')
            if (len(ohlcvs) > 1):
                first = ohlcvs[0][0]
                last = ohlcvs[-1][0]
            else:
                first = ohlcvs
                last = ohlcvs

            if (fetch_status == True):
                print('First candle epoch', first, exchange.iso8601(first))
                print('Last candle epoch', last, exchange.iso8601(last))

            # either remove or include additoinal params like day or month , whatever ccxt allows
            from_timestamp += len(ohlcvs) * minute
            data += ohlcvs

        except:

            print('Got an error. Retrying in', hold, 'seconds...')
            time.sleep(hold)
    data = pd.DataFrame(data, columns=['Timestamp_ms', 'Open_Price', 'Highest_Price', 'Lowest_Price', 'Closing_Price',
                                       'Volume'])
    data = data.dropna()
    return data
def fetch_and_format_data(symbol='BTC/USDT',
                          from_datetime=(int(round(time.time() * 1000))) - 10000000,
                          timeframe='1m',
                          exchange=ccxt.binance({'rateLimit': 5000,
                                                 'enableRateLimit': True,
                                                 'recvWindow': 1000000000000,
                                                 'nonce': ccxt.Exchange.milliseconds,
                                                 'options': {'adjustForTimeDifference': True}})):
    '''
     576300000 should account for the last 10000 data sets, allowing for propper training, and predictions
                              from_datetime='2018-01-01 00:00:00',
'''
    btc_df_latest = fetch_OHLCV_data(exchange=exchange,
                                              symbol=symbol,
                                              timeframe=timeframe,
                                              from_datetime=from_datetime)  # Fetches OHLCV data
    # From AI_Crypto_GUI.py
    btc_withLabel, _ = label_perfect_trades(btc_df_latest, 0, True)  # Labels data

    pickle.dump(btc_withLabel, open('btc_labeled.p', 'wb'))  # dumps df btc_withLabel to pickle file


def label_perfect_trades(priceHistory, triggerPrice, new_training=False):
    # labels perfect trades as peaks , valleys or neutral
    # params
    # priceHistory - dataframe of OHLCVS
    firstround = True
    label_df = pd.DataFrame(columns=['target'])
    modified_label_df = pd.DataFrame(columns=['modifiedTarget'])
    label_df['Closing_Price'] = priceHistory['Closing_Price'].values
    if (new_training == True):
        triggerPrice = label_df['Closing_Price'].at[0]
    else:
        triggerPrice = triggerPrice
    for i in range(len(label_df['Closing_Price'].values) - 1):
        if label_df['Closing_Price'].at[i + 1] > triggerPrice + (triggerPrice * 0.001):
            label_df['target'].at[i + 1] = 2
            triggerPrice = label_df['Closing_Price'].at[i + 1]
        elif label_df['Closing_Price'].at[i + 1] < triggerPrice - (triggerPrice * 0.001):
            label_df['target'].at[i + 1] = 1

            triggerPrice = label_df['Closing_Price'].at[i + 1]
        else:
            label_df['target'].at[i + 1] = 0

    for j in range(len(label_df['target'].values)):
        if(label_df['target'].at[j] == 1 or label_df['target'].at[j] == 2):
            if (firstround):
                action_comparision['previousAction'] = label_df['target'].at[j]
                modified_label_df['modifiedTarget'].at[j] = label_df['target'].at[j]
                firstround = False
            else:
                action_comparision['presentAction'] = label_df['target'].at[j]
                print('Pres - ', action_comparision['previousAction'], 'prev  -', action_comparision['presentAction'])
                if (action_comparision['presentAction'] != action_comparision['previousAction']):
                    modified_label_df['modifiedTarget'].at[j] = label_df['target'].at[j]
                    action_comparision['previousAction'] = label_df['target'].at[j]

                else:
                    modified_label_df['modifiedTarget'].at[j] = 0

        else:
            modified_label_df['modifiedTarget'].at[j] = 0


    print(modified_label_df['modifiedTarget'])

    priceHistory = pd.concat([priceHistory, label_df.drop('Closing_Price', 1),modified_label_df['modifiedTarget']], 1)
    #        if (len(priceHistory) > 2):
    #            priceHistory.fillna(0).to_csv('formatted_data.csv')
    return priceHistory.fillna(0), triggerPrice
fetch_and_format_data()
variable = pickle.load(open('btc_labeled.p', 'rb'))

print(variable)
