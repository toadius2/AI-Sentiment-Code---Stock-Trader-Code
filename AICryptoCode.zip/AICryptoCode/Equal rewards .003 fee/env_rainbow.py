from collections import deque
import random
import torch
import matplotlib.pyplot as plt
import numpy as np
import os.path
import pickle
import math
from torch.autograd import Variable
import torch
import talib
import itertools
import pandas as pd
pd.options.mode.chained_assignment = None  # default='warn'

script_path = os.path.dirname(__file__)
plt.style.use('seaborn-paper')


class Env():
  def __init__(self, train_df, train_label, init_act):
    actions = [0,1,2]
    self.actions = dict([i, e] for i, e in zip(range(len(actions)), actions))
    self.init_act = init_act
    self.i_step = 0
    self.i_act = init_act
    self.OHLCV = None
    self.reward = None
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    train_df = pd.DataFrame(scaler.fit_transform(train_df.values), columns=train_df.columns)
    self.train_df = torch.from_numpy(np.expand_dims(train_df.values, axis=1).astype(np.float32))
    self.train_label = train_label.values
    self.iter = None
    self.state_buffer = deque([])
    self.training = True  # Consistent with model training mode

  def _pos_encode(self):
      pos = torch.zeros((1, 3))
      # print(self.i_act)
      pos[0, self.i_act] = 1.
      return pos

  def _get_state(self):
    self.iter = zip(iter(self.train_df), iter(self.train_label))

    s0, self.OHLCV = next(self.iter)
    return torch.cat((s0, self._pos_encode()), dim=1)

  def _reset_buffer(self):
    for _ in range(self.window):
      self.state_buffer.append(torch.zeros(84, 84, device=self.device))

  def reset(self):
    self.i_step = 0
    self.i_act = self.init_act
    self.OHLCV = None
    self.reward = None

    self.iter = zip(iter(self.train_df), iter(self.train_label))

    s0, self.OHLCV = next(self.iter)
    # print(' ___s0: ' , s0)
    # print(' self.posencode: ', self._pos_encode())
    return torch.cat((s0, self._pos_encode()), dim=1)

    observation = s0
    self.state_buffer.append(observation)
    # return torch.stack(list(self.state_buffer), 0)

  def step(self, a):
    self.i_step += 1
    s_, self.OHLCV = next(self.iter)
    target = self.OHLCV

    # values, a_index = a.max(0)
    pred = a
    label_counts = {}
    for i in self.train_label:
      # get(key, default) falls back to default if key is not present
      label_counts[i] = label_counts.get(i, 0) + 1
    if len(label_counts.keys()) == 3:

      if pred == target == 2:
        self.reward = 1000 * (1 / label_counts[2])
      elif pred == target == 1:
        self.reward = 1000 * (1 / label_counts[1])
      elif pred == target == 0:
        self.reward = 1000 * (1 / label_counts[0])


      elif target == 1 and pred != 1:
        self.reward = -(1000 * (1 / label_counts[1]))
      elif target == 2 and pred != 2:
        self.reward = -(1000 * (1 / label_counts[2]))
      elif target == 0 and pred != 0:
        self.reward = -(1000 * (1 / label_counts[0]))

    elif len(label_counts.keys()) == 2:
      if pred == target == list(label_counts.keys())[0]:
        self.reward = 1000 * (1 / label_counts[list(label_counts.keys())[0]])
      elif pred == target == list(label_counts.keys())[1]:
        self.reward = 1000 * (1 / label_counts[list(label_counts.keys())[1]])

      elif pred == list(label_counts.keys())[0] and target != list(label_counts.keys())[0]:
        self.reward = -1 * 1000 * (1 / label_counts[list(label_counts.keys())[0]])
      elif pred == list(label_counts.keys())[1] and target != list(label_counts.keys())[1]:
        self.reward = -1 * 1000 * (1 / label_counts[list(label_counts.keys())[1]])
      else:
        self.reward = ((1 * 1000 * (1 / label_counts[list(label_counts.keys())[0]])) + 1 * 1000 * (
                  1 / label_counts[list(label_counts.keys())[1]])) / -2
    else:
      if pred == target:
        self.reward = 1000 * (1 / label_counts[list(label_counts.keys())[0]])

      else:
        self.reward = -1 * 1000 * (1 / label_counts[list(label_counts.keys())[0]])
    if self.reward == None:
      print(len(label_counts))
      print(label_counts.keys())
      print(self.reward)
      print(pred)
      print(target)
    # swap action
    self.i_act = a
    if self.i_step % 10000 == 0:
      print(self.i_step, ', ', self.i_act.item(), ', ', self.reward)
    # done
    done = False if self.i_step < len(self.train_df) - 1 else True


    return torch.cat((s_, self._pos_encode()), dim=1), self.reward, done
  # Uses loss of life as terminal signal
  def train(self):
    self.training = True

  # Uses standard terminal signal
  def eval(self):
    self.training = False

  def action_space(self):
    return len(self.actions)

  def curr_OHLCV(self):
    return self.OHLCV