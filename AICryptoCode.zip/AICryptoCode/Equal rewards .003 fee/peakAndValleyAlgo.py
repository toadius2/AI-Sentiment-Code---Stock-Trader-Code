from collections import defaultdict
import pandas as pd
data1= [ 50, 60, 90, 70, 40, 20, 21, 22, 23, 70]
data2 = [10, 20, 30, 50, 60, 40, 20, 1, 20, 200, 10,210]
data3 = [5543.11, 5541.39, 5538.8,5538.25, 5535.82,5540.98,5541.4,5538.67,5538.62,5539.55,5537.95,5530.22,5528.98,5524.29,5534.24,5532.72]
data4 = [5000, 5001, 5002, 5003, 5004, 5005, 5006, 5007, 5008, 5009, 5010, 5011, 5012,5013]
result =[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 2, 0]
realLabel1 = [1, 0, 0, 0, 2, 0, 0, 1, 0 , 2,1, 2]
intermRes = [1, 2, 2, 1, 1, 1, 0, 0, 0, 2]
realLabel = [1, 0, 2, 0, 0, 1, 0, 0, 0, 2]
data_df = pd.read_csv('data.csv')
data  = data_df['Closing_Price'].values
print(data)

label = []
dict1 = {}
dict2 = {}
dict_count = defaultdict(int)
trigger = data[0]
diff = []
trigg_val_per = []
for i in range(0, len(data)):
    print("Iteration", i)
    print("count", dict_count[2], dict_count[1])
    # if i ==0:
    #     if data[i] > 1.001 * data[i+1]:
    #         trigger = data[i]
    #         label.append(2)
    #
    #         if 2 not in dict_count:
    #             dict_count[2] = 1
    #         else:
    #             dict_count[2] += 1
    #
    #     elif data[i] < 0.9999 * data[i+1]:
    #         trigger = data[i]
    #         label.append(1)
    #
    #         if 1 not in dict_count:
    #             dict_count[1] = 1
    #         else:
    #             dict_count[1] += 1
    #     else:
    #         trigger = data[i]
    #         label.append(0)
    #
    # else:
    print(trigger)
    diff.append(abs(trigger - data[i]))
    trigg_val_per.append(abs(trigger*0.001))
    if data[i] > 1.001 * trigger:
        if dict_count[1] >= 2:
            dict_count[1] = 1
            dict2 = {}

        trigger = data[i]
        label.append(2)

        if 2 in dict2:
            label[dict2[2]] = 0
            dict2[2] = i

        else:
            dict2[2] = i

        if 2 not in dict_count:
            dict_count[2] = 1
        else:
            dict_count[2] += 1



    elif data[i] < 0.999 * trigger:
        if dict_count[2] >= 2:
            dict_count[2] = 1
            dict1 = {}

        trigger = data[i]
        label.append(1)

        if 1 in dict1:
            label[dict1[1]] = 0
            dict1[1] = i
        else:
            dict1[1] = i

        if 1 not in dict_count:
            dict_count[1] = 1
        else:
            dict_count[1] += 1
    else:
        # trigger = data[i]
        label.append(0)

print(label)
df = pd.DataFrame(
    {'Label': label,
     'Diff': diff,
     'Trigger': trigg_val_per,
     'Closing Price': data
    })
df.to_csv("labeldf.csv")